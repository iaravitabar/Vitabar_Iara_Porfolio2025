

/*
 * EJERCICIO 4
Ingrese el siguiente código fuente en su proyecto (una clase “Alumno” y varios métodos
independientes, que no son de la clase “Alumno”) :
public class Alumno {
    private String nombre;
    public Alumno () {
        nombre = null;
    }
    public String getNombreAdmiracion() {
        return nombre.concat("!");
    }
    public static void main (String[] args) {
        Alumno alumno = new Alumno();
    System.out.println(alumno.getNombreAdmiracion());
    }

public static int recorrer (String cadena) {
    int res = 0;
    for (int i = 1; i <= cadena.length(); i++) {
        if (cadena.charAt(i) != ' ') {
            res++;
    }
        }
        return res;
}
public static int getValor() {
    int vector[] = { 6, 16, 26,36,46,56,66,76 };
    int idx = 8;
    return vector[idx];
}
public static char getPrimerCaracter(String palabra) {
    String string[] = new String[5];
    return (string[1].charAt(1));
}
public static String paraAString(int a) {
    Object x1 = new Integer(a);
    return (String) (x1) ;
}}

a) Indicar el error al ejecutar la clase Alumno y corregirlo. ¿cómo lo detectaste?
    Hay metodos definidos fuera de la clase, para eso hay que mover la llaves de cierre al final.
b) Indicar el error al ejecutar el método “recorrer” y corregirlo. ¿cómo lo detectaste?
    en el bucle for tiene que empezar desde 0 y no desde i =1 por los indices.
    Por eso tambien, el bucle debe ser hasta i < cadena.length()
c) Indicar el error al ejecutar el método “getValor” y corregirlo. ¿cómo lo detectaste?
    no existe el indice 8, el maximo es 7
d) Indicar el error al ejecutar el método “getPrimerCaracter” y corregirlo. ¿cómo lo detectaste?
    el indice del array debe empezar en 0 y no se inicializa el array "string"
e) Indicar el error al ejecutar el método “paraAString” y corregirlo. ¿cómo lo detectaste?
    para convertir un objeto a string se usa el metodo toString()
 */
public class Alumno {
    private String nombre;
    public Alumno () {
        nombre = null;
    }
    public String getNombreAdmiracion() {
        return nombre.concat("!");
    }
    public static void main (String[] args) {
        Alumno alumno = new Alumno();
    System.out.println(alumno.getNombreAdmiracion());
    }
public static int recorrer (String cadena) {
    int res = 0;
    for (int i = 1; i < cadena.length(); i++) {
        if (cadena.charAt(i) != ' ') {
            res++;
    }
        }
        return res;
}
public static int getValor() {
    int vector[] = { 6, 16, 26,36,46,56,66,76 };
    int idx = 7;
    return vector[idx];
}
public static char getPrimerCaracter(String palabra) {
    String string[] = {"a","bcd","fg"};
    return (string[0].charAt(0));
}
public static String paraAString(int a) {
    Integer x1 = new Integer(a);
    return x1.toString() ;
}
}

        