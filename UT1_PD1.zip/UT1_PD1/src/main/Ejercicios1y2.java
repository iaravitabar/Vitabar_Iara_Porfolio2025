
/**
 * EJERCICIO #1
 * public static void zoop () {
    baffle ();
    System.out.print ("Vos zacata ");
    baffle ();
    }
    public static void main (String[] args) {
    System.out.print ("No, yo ");
    zoop ();
    System.out.print ("Yo ");
    baffle ();
    }
    public static void baffle () {
    System.out.print ("pac");
    ping ();
    }
    public static void ping () {
    System.out.println (".");
    }
    ¿Cuál es la salida? Sé preciso acerca de dónde hay espacios y dónde hay nuevas líneas.
    Indicar cuál es la respuesta más correcta: (\n denota nueva línea)

    main: printea "No, yo ", llama met Zoop()
    zoop: llama met baffle(), printea "Vos Zacata ", llama a baffle()
    baffle:printea "pac", llama met ping()
    ping: printea "."
        La salida será:
            No, yo pac. ("pac" se imprime en la misma línea debido a System.out.print(), se imprime "." por el metodo ping y salta a una nueva linea)
            Vos zacata pac. (se imprime dentro de zoop() usando System.out.print(), se llama a baffle() e imprime "pac en la misma linea, se imprime "." por el metodo ping y salta a una nueva linea")
            Yo pac. ("yo" se imprime dentro de main, se vuelve a llamar a baffle(), y termina una nueva linea debido a System.out.println en el metodo ping)


        EJERCICIO 2
    Dado el siguiente código fuente:
        public class Zumbido {

        public static void desconcertar (String dirigible) {
            System.out.println (dirigible);         5-10-15
            sipo ("ping", -5);          6-11-16
        }
        public static void sipo (String membrillo, int flag) {
            if (flag < 0) {
            System.out.println (membrillo + " sup");        2-7-12
            } else {
            System.out.println ("ik");          3-8-13
            desconcertar (membrillo);           4-9-14
            System.out.println ("muaa-ja-ja-ja");
            }
        }
        public static void main (String[] args) {
            sipo ("traqueteo", 13);         1
            }
        }
    a) ¿Cuál es la primera sentencia que se ejecuta?
        La primera es la del método sipo() en el método main(), con los arguentos "traqueteo" y 13

    b) Escribir número 2 al lado de la segunda sentencia, un 3 al lado de la que se ejecuta en
    tercer lugar, y así siguiendo hasta el final del programa. Si una sentencia se ejecuta más
    de una vez, puede que termine con más de un número al lado.
*/