package com.example;

/**
 * PRACTICOS DOMICILIARIOS INDIVIDUALES #9
    EJERCICIO #1
    Implementar un método que calcule el factorial de un número entero cualquiera, siendo
    este un parámetro del método. Utilizar únicamente bucles for.
    Si N=3 entonces factorial(N) = 3.2.1 = 6
    Una posible firma del método:
    public static int factorial(int num)
    {...}
    NOTA : CONSIDERAR CONDICIONES DE BORDE Y CHEQUEOS DE ERRORES
 */
public class Factorial {

    public static void main(String[] args) {
        int N = 3;
        System.out.println("El factorial de " + N + " es: " + factorial(N));
    }
    public static int factorial(int num) {
        int factorial = 1;
        for (int i = 1; i <= num; i++) {
            factorial *= i;
        }
        if (num < 0) { // caso borde
            throw new IllegalArgumentException("digito invalido, no puede ser negativo");
        }
        if (num == 0) { //caso borde
            return 1;
        }
        return factorial;
    }
}
