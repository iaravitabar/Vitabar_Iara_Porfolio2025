package com.example;

/*
 * Ejercicio #2
    Hacer un programa en Java que indique si un número dado es primo. Si lo es, el programa
    deberá calcular la suma de los números pares desde 0 hasta el número dado, y en caso
    contrario deberá calcular la suma de los números impares desde 0 hasta el número dado.
    Utilizar solamente sentencias while o do-while.
    Posible código para calcular si un número es primo:
 */

public class NumPrimo {

    public static void main(String[] args){
        long numero = 10;
        if  (EsPrimo(numero)){
            System.out.println(numero + "es primo");
            System.out.println("suma de los pares es:"+ SumPares(numero));
        } else{
            System.out.println(numero + "no es primo");
            System.out.println("la suma de impares es:"+ SumImpar(numero));
        }
    }

    public static boolean EsPrimo(long n) {
        boolean prime = true;
        for (long i = 3; i <= Math.sqrt(n); i += 2)
            if (n % i == 0) {
                prime = false;
                break;
            }
        if (( n%2 !=0 && prime && n > 2) || n == 2) {
            return true;
        } else {
            return false;
        }
    }
      
    public static long SumPares(long n){
        long sum = 0;
        long numero = 0;
        while (numero<= n){
            sum+=numero;{
        }
        numero++;
    }
    return  sum;
    }
    public static long SumImpar(long n){
        long sum=0;
        long numero=0;
        while (numero<= n){
            if(numero %2 != 0){
                sum += numero;
            }
            numero++;
        }
        return sum;
    }
}

