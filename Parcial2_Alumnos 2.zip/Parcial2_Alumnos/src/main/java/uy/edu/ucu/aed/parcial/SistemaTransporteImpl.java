package uy.edu.ucu.aed.parcial;

import java.util.LinkedList;
import java.util.List;

import uy.edu.ucu.aed.modelo.Recorrido;

public class SistemaTransporteImpl extends LinkedList<ISistemaTransporte>{

    
}