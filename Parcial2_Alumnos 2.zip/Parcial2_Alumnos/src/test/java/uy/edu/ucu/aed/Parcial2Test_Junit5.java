package uy.edu.ucu.aed;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;


import static org.junit.jupiter.api.Assertions.*;

import uy.edu.ucu.aed.modelo.*;
import uy.edu.ucu.aed.parcial.ISistemaTransporte;
import uy.edu.ucu.aed.parcial.SistemaTransporteImpl;
import uy.edu.ucu.aed.tdas.TArista;
import uy.edu.ucu.aed.tdas.TGrafoDirigido;
import uy.edu.ucu.aed.tdas.TVertice;

import java.util.Collection;
import java.util.LinkedList;
import java.util.List;

/**
 * Tests completos para el sistema de transporte.
 * Valida la funcionalidad de ciudades, carreteras, camiones y cálculo de rutas.
 */
public class Parcial2Test_Junit5
{
    TGrafoDirigido grafo;
    ISistemaTransporte sistema;
    SistemaTransporteImpl sistemasImpl;

    @BeforeEach
    public void setUp() {
        TVertice ciudadDestino = new TVertice("maldonado", 3);
        TVertice ciudadOrigen = new TVertice("montevideo", 0);

        Collection<TVertice> vertices = new LinkedList<>();
        vertices.add(ciudadDestino);
        vertices.add(ciudadOrigen);

        Collection<TArista> aristas = new LinkedList<>();
        aristas.add(ciudadOrigen, ciudadDestino);

        ISistemaTransporte sistema = new SistemaTransporteImpl();

    }

    @AfterEach
    public void tearDown() {
        sistema = null;
    }

    @Test
    public void hayCamino() {
        assertEquals(sistema.ruta("montevideo", "Maldonado"));
    }
    public void noHayCamino(){
        assertFalse(sistema.ruta("montevideo", "rivera"));
    }
    public void esElMismo(){
        assertFalse(sistema.ruta("montevideo", "montevideo"));
    }
    public void origenNulo(){
        assertNull(sistema.ruta("null", "maldonado"));
    }
    public void destinoNulo(){
        assertNull(sistema.ruta("montevideo", "null"));
    }

}
