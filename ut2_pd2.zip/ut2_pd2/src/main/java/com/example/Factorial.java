package com.example;

public class Factorial {
    public static int Calcfactorial(int n){
        if (n ==0 || n == 1){
            return 1;
        }
        else{
            return n*Calcfactorial(n-1);
        }
    }
}
