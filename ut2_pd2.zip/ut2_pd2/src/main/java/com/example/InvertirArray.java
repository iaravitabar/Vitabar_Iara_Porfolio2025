package com.example;

public class InvertirArray {
    public static void invertirArray(int [] A, int i, int j){
        if (i<=j){
            int temp = A[i];
            A[i] = A[j];
            A[j] = temp;

            invertirArray(A, i+1, j-1);
        }
    }
}
