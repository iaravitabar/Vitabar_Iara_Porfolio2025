package com.example;

public class SumaLineal {
    public static int sumaLineal(int[]A, int n){
        if (n ==1){
            return A[0];
        }
        else{
            return sumaLineal (A, n-1)+A[n-1];
        }
    }
}
