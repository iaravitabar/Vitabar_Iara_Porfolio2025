package com.example;

public class Main {
    public static void main(String[] args) {
        // int n = 0;
        // int resultado = Factorial.Calcfactorial(n);
        // System.out.println("resultado:"+ resultado);

        // int [] array = {1,2,3};
        // int n = 2;
        // int resultado = SumaLineal.sumaLineal(array, n);
        // System.out.println("sum primeros " + n + " elem es  "+ resultado);

        // int n = 2;
        // int e = 2;
        // int resultado = Potencia.CalcPotencia(n, e);
        // System.out.println("potencia de " + n + "elevado a " + e + "es " + resultado);

        int [] array = {1,2,3,4};
        int i = 1;
        int j = 3;
        InvertirArray.invertirArray(array, i, j);
        System.out.println("array invertido " );
        for (int k = 0; k < array.length; k++) {
            System.out.print(array[k] + " ");
        }
    }
}