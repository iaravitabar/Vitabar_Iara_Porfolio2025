package com.example;

public class Potencia {
    public static int CalcPotencia(int n, int e){
        if (e==0){
            return 1;
        }
        else{
            return n*CalcPotencia(n, e-1);
        }
    }
}
