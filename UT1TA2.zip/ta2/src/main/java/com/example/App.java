package com.example;

public class App 
{
    public static void main( String[] args )
    {
        System.out.println(UtilMath.factorial(5));
        System.out.println(UtilMath.factorial(10));

        long n = 10; 
        System.out.println("(NO PRIMO) La suma es: " + UtilMath.sumarEnBaseAPrimos(n));

        long j = 5;
        System.out.println("(PRIMO) La suma es: " + UtilMath.sumarEnBaseAPrimos(j));


    }
}
