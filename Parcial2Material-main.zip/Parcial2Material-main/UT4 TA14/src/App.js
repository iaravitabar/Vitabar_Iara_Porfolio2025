import "./styles.css";
import { createContext, useContext, useState } from "react";

const ThemeContext = createContext();

function TemaActual() {
  const oscuro = useContext(ThemeContext);
  return (
    <div>
      <p>¿Oscuro? {oscuro ? "Sí" : "No"}</p>
    </div>
  );
}

function CambiarTema({ setTema }) {
  const oscuro = useContext(ThemeContext);
  const cambiar = () => {
    setTema(!oscuro);
  };
  return (
    <div>
      <button className="boton" onClick={cambiar} placeholder="CambiarTema">
        Cambiar tema
      </button>
    </div>
  );
}

export default function App() {
  const [temaOscuro, setTema] = useState(true);
  return (
    <ThemeContext.Provider value={temaOscuro}>
      <div className={temaOscuro ? "dark" : "white"}>
        <TemaActual />
        <CambiarTema setTema={setTema} />
      </div>
    </ThemeContext.Provider>
  );
}
