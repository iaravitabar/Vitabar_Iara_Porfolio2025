import React, { useContext, useEffect } from "react";
import { TasksContext } from "../../contexts";
import Task from "../Task";
import classes from "./tasksList.module.css";

const TasksList = ({ name, filterState }) => {
  const { tasks, handleDeleteTask, handleEditTask } = useContext(TasksContext);
  const filteredTasks = tasks.filter((task) => task.status === filterState);


  return (
    <div className={classes.tasksContainer}>
      <div className={classes.tasksHeader}>
        <h1 className={classes.tasksTitle}>{name}</h1>
      </div>
      {filteredTasks.length > 0 ? (
        <div className={classes.tasksList}>
          {filteredTasks.map((task, index) => (
            <Task
              key={task.id}
              title={task.title}
              description={task.description}
              priority={task.priority}
              assignedTo={task.assignedTo}
              endDate={task.endDate}
              onDelete={() => handleDeleteTask(task.id)}
              onEdit={() => handleEditTask(task.id)}
            />
          ))}
        </div>
      ) : (
        <p className={classes.tasksEmpty}>No hay tareas</p>
      )}
    </div>
  );
};

export default TasksList;
