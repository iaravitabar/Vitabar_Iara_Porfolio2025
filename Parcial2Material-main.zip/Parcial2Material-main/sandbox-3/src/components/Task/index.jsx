import React, { useState } from "react";
import classes from "./task.module.css";

const Task = ({
  id,
  title,
  description,
  startDate,
  endDate,
  priority,
  assignedTo,
  onDelete,
  onEdit,
}) => {
  const [isCompleted, setIsCompleted] = useState(false);

  const handleCheckboxClick = () => {
    setIsCompleted((prevState) => !prevState);
  };

  return (
    <div className={classes.taskCard}>
      <div className={classes.leftDecorator}></div>
      <div className={classes.contentWrapper}>
        <div className={classes.arribaHalf}>
          <div className={classes.taskDetails}>
            <h3
              className={`${classes.taskName} ${
                isCompleted ? classes.completed : ""
              }`}
            >
              {title}
            </h3>
            <p
              className={`${classes.taskDescription} ${
                isCompleted ? classes.completed : ""
              }`}
            >
              {description}
            </p>
            <div className={classes.tagsGroup}>
              <span className={classes.tag}>{assignedTo} </span>
              <span className={classes.tag}>{priority}</span>
            </div>
          </div>
          <input
            type="checkbox"
            className={classes.taskCheck}
            onChange={handleCheckboxClick}
            checked={isCompleted}
          />
        </div>
        <div className={classes.abajoHalf}>
          <div className={classes.buttonWrapper}>
            <button onClick={onDelete} className={classes.button}>
              <svg
                xmlns="http://www.w3.org/2000/svg"
                height="24px"
                viewBox="0 -960 960 960"
                width="24px"
                fill="#EA3323"
              >
                <path d="M280-120q-33 0-56.5-23.5T200-200v-520h-40v-80h200v-40h240v40h200v80h-40v520q0 33-23.5 56.5T680-120H280Zm400-600H280v520h400v-520ZM360-280h80v-360h-80v360Zm160 0h80v-360h-80v360ZM280-720v520-520Z" />
              </svg>
            </button>
            <button onClick={onEdit} className={classes.button}>
              <svg
                xmlns="http://www.w3.org/2000/svg"
                height="24px"
                viewBox="0 -960 960 960"
                width="24px"
                fill="#F19E39"
              >
                <path d="M200-200h57l391-391-57-57-391 391v57Zm-80 80v-170l528-527q12-11 26.5-17t30.5-6q16 0 31 6t26 18l55 56q12 11 17.5 26t5.5 30q0 16-5.5 30.5T817-647L290-120H120Zm640-584-56-56 56 56Zm-141 85-28-29 57 57-29-28Z" />
              </svg>
            </button>
          </div>
          <p className={classes.taskDeadline}>{endDate}</p>
        </div>
      </div>
    </div>
  );
};

export default Task;
