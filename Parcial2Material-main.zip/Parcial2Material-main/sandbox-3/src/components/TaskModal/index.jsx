import React, { useContext } from "react";
import classes from "./modal.module.css";
import { TaskModalContext } from "../../contexts";

const TaskModal = ({
  onClose,
  onCreate,
  onUpdate,
  personas,
  prioridades,
  estados,
}) => {
  const convertDateFormat = (date) => {
    let separator = date.indexOf('/') > -1 ? '/' : '-';
    if (!date) return ''; 
    if (separator === '/') {
      const [day, month, year] = date.split(separator);
      return `${year}-${month}-${day}`;
    }
    const [year, month, day] = date.split(separator);
    return `${year}-${month}-${day}`;
  };
  
  const {
    title,
    description,
    endDate,
    editing,
    taskId,
    assignedTo,
    priority,
    status,
    setModalData,
  } = useContext(TaskModalContext);

  const handleSubmit = (e) => {
    e.preventDefault();

    const taskData = {
      title,
      description,
      endDate,
      startDate: new Date().toLocaleDateString(),
      assignedTo,
      priority,
      status,
    };

    if (editing) {
      onUpdate(taskData, taskId);
    } else {
      onCreate(taskData);
    }

    setModalData({
      title: "",
      description: "",
      endDate: "",
      assignedTo: "",
      priority: "",
      status: "",
      editing: false,
      taskId: null,
    });
    onClose();
  };

  return (
    <div className={classes.modalOverlay}>
      <div className={classes.modalContent}>
        <div className={classes.modalHeader}>
          <h2 className={classes.modalTitle}>
            {editing ? "Editar tarea" : "Crear nueva tarea"}
          </h2>
          <button
            className={classes.closeButton}
            onClick={() => {
              setModalData({
                title: "",
                description: "",
                endDate: "",
                assignedTo: "",
                priority: "",
                status: "",
                editing: false,
                taskId: null,
              });
              onClose();
            }}
          >
            &times;
          </button>
        </div>
        <form onSubmit={handleSubmit}>
          <div className={classes.modalBody}>
            <input
              type="text"
              className={classes.inputField}
              placeholder="Título de la tarea"
              value={title}
              onChange={(e) =>
                setModalData((prev) => ({ ...prev, title: e.target.value }))
              }
              required
            />
            <textarea
              className={classes.inputField}
              placeholder="Descripción"
              value={description}
              onChange={(e) =>
                setModalData((prev) => ({
                  ...prev,
                  description: e.target.value,
                }))
              }
              required
            />
            <input
              type="date"
              className={classes.inputField}
              value={convertDateFormat(endDate)}
              onChange={(e) =>
                setModalData((prev) => ({ ...prev, endDate: e.target.value }))
              }
              required
            />
            <select
              className={classes.inputField}
              value={assignedTo}
              onChange={(e) =>
                setModalData((prev) => ({
                  ...prev,
                  assignedTo: e.target.value,
                }))
              }
              required
            >
              <option value="">Seleccionar persona</option>
              {personas.map((persona, index) => (
                <option key={index} value={persona}>
                  {persona}
                </option>
              ))}
            </select>

            <select
              className={classes.inputField}
              value={priority}
              onChange={(e) =>
                setModalData((prev) => ({ ...prev, priority: e.target.value }))
              }
              required
            >
              <option value="">Seleccionar prioridad</option>
              {prioridades.map((prioridad, index) => (
                <option key={index} value={prioridad}>
                  {prioridad}
                </option>
              ))}
            </select>

            <select
              className={classes.inputField}
              value={status}
              onChange={(e) =>
                setModalData((prev) => ({ ...prev, status: e.target.value }))
              }
              required
            >
              <option value="">Seleccionar estado</option>
              {estados.map((estado, index) => (
                <option key={index} value={estado}>
                  {estado}
                </option>
              ))}
            </select>

            <button type="submit" className={classes.submitButton}>
              {editing ? "Editar tarea" : "Crear tarea"}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default TaskModal;
