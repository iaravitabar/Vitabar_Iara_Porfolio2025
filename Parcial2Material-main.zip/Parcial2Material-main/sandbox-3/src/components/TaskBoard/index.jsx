import React, { useContext, useState } from "react";
import { TasksContext } from "../../contexts";
import classes from "./taskBoard.module.css";
import TaskList from "../TasksList";

const TaskBoard = ({ openModal }) => {
  const { tasks } = useContext(TasksContext);
  const [theme, setTheme] = useState("light");

  const handleChange = () => setTheme(theme === "light" ? "dark" : "light");

  return (
    <div className={classes.tasksContainer} data-theme={theme}>
      <div className="container-switch">
        <span>Change Theme</span>
        <label className="switch">
          <input
            type="checkbox"
            onChange={handleChange}
            checked={theme === "dark"}
          />
          <span className="slider"></span>
        </label>
      </div>

      <div className={classes.tasksHeader}>
        <h1 className={classes.tasksTitle}>Lista de tareas</h1>
        <div className={classes.tasksButtons}>
          <button className={classes.button} onClick={openModal}>
            Nueva tarea
          </button>
          <button className={classes.boton} onClick={openModal}>
            +
          </button>
        </div>
      </div>

      {tasks.length > 0 ? (
        <div className={classes.tasksRow}>
          <TaskList name="Backlog" filterState="Backlog" />
          <TaskList name="To Do" filterState="To Do" />
          <TaskList name="In Progress" filterState="In Progress" />
          <TaskList name="Blocked" filterState="Blocked" />
          <TaskList name="Done" filterState="Done" />
        </div>
      ) : (
        <p className={classes.tasksEmpty}>No hay tareas</p>
      )}
    </div>
  );
};

export default TaskBoard;
