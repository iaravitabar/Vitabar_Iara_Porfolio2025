import React, { useState, useEffect } from "react";
import axios from "axios";
import TaskModal from "./components/TaskModal";
import TaskBoard from "./components/TaskBoard";
import { TasksContext, TaskModalContext } from "./contexts";

export default function App() {
  const [tasks, setTasks] = useState([]);
  const [showModal, setShowModal] = useState(false);
  const [modalData, setModalData] = useState({
    title: "",
    description: "",
    endDate: "",
    assignedTo: "",
    status: "",
    priority: "",
    editing: false,
    taskId: null,
  });

  useEffect(() => {
    const fetchTasks = async () => {
      try {
        const response = await axios.get("http://localhost:3000/api/tasks");
        setTasks(response.data);
      } catch (error) {
        console.error("Error fetching tasks:", error);
      }
    };

    fetchTasks();
  }, []);

  const handleCreateTask = async (newTask) => {
    try {
      const response = await axios.post("http://localhost:3000/api/tasks", newTask);
      setTasks((prevTasks) => [...prevTasks, response.data]);
    } catch (error) {
      console.error("Error creating task:", error);
    }
  };

  const handleUpdateTask = async (updatedTask, taskId) => {
    try {
      const response = await axios.put(`http://localhost:3000/api/tasks/${taskId}`, updatedTask);
      setTasks((prevTasks) => {
        const updatedTasks = [...prevTasks];
        updatedTasks[updatedTasks.findIndex((task) => task.id === taskId)] = response.data;
        return updatedTasks;
      });
    } catch (error) {
      console.error("Error updating task:", error);
    }
  };

  const handleDeleteTask = async (taskId) => {
    try {
      await axios.delete(`http://localhost:3000/api/tasks/${taskId}`);
      setTasks((prevTasks) => prevTasks.filter((task) => task.id !== taskId));
    } catch (error) {
      console.error("Error deleting task:", error);
    }
  };

  const handleEditTask = (taskId) => {
    const taskToEdit = tasks.find((task) => task.id === taskId);
    setModalData({ ...taskToEdit, editing: true, taskId });
    setShowModal(true);
  };

  return (
    <TasksContext.Provider
      value={{
        tasks,
        handleCreateTask,
        handleUpdateTask,
        handleDeleteTask,
        handleEditTask,
      }}
    >
      <TaskModalContext.Provider value={{ ...modalData, setModalData }}>
        <TaskBoard
          openModal={() => {
            setModalData({
              title: "",
              description: "",
              endDate: "",
              assignedTo: "",
              status: "",
              priority: "",
              editing: false,
              taskId: null,
            });
            setShowModal(true);
          }}
        />
        {showModal && (
          <TaskModal
            onClose={() => setShowModal(false)}
            onCreate={handleCreateTask}
            onUpdate={handleUpdateTask}
            personas={["Rodrigo Lujambio", "Michel Sampil", "Jose Abadie"]}
            prioridades={["High", "Medium", "Low"]}
            estados={["Backlog", "To Do", "In Progress", "Blocked", "Done"]}
          />
        )}
      </TaskModalContext.Provider>
    </TasksContext.Provider>
  );
}
