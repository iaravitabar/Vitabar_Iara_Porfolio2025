import { createContext } from "react";

export const TasksContext = createContext();
export const TaskModalContext = createContext();
