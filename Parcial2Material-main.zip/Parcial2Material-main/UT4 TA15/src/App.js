import "./styles.css";
import { createContext, useContext, useState } from "react";

const ThemeContext = createContext();
const IdiomaContext = createContext();

function TemaActual() {
  const oscuro = useContext(ThemeContext);
  return (
    <div>
      <p>¿Oscuro? {oscuro ? "Sí" : "No"}</p>
    </div>
  );
}
function IdiomaActual() {
  const idioma = useContext(IdiomaContext);
  return (
    <div>
      <p>Idioma: {idioma}</p>
    </div>
  );
}

function CambiarTema({ setTema }) {
  const oscuro = useContext(ThemeContext);
  const cambiar = () => {
    setTema(!oscuro);
  };
  return (
    <div>
      <button className="boton" onClick={cambiar} placeholder="CambiarTema">
        Cambiar tema
      </button>
      <TemaActual />
    </div>
  );
}

function CambiarIdioma({ setIdioma }) {
  const cambioIdioma = (event) => {
    setIdioma(event.target.value);
  };

  return (
    <div>
      <input
        type="text"
        placeholder="Elija un idioma"
        onChange={cambioIdioma}
      />
      <IdiomaActual />
    </div>
  );
}

export default function App() {
  const [temaOscuro, setTema] = useState(false);
  const [idioma, setIdioma] = useState("");
  return (
    <ThemeContext.Provider value={temaOscuro}>
      <IdiomaContext.Provider value={idioma}>
        <div className={temaOscuro ? "dark" : "white"}>
          <CambiarIdioma setIdioma={setIdioma} />
          <CambiarTema setTema={setTema} />
        </div>
      </IdiomaContext.Provider>
    </ThemeContext.Provider>
  );
}
