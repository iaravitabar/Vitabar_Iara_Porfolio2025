import "./styles.css";
import { createContext, useContext } from "react";

const UserContext = createContext();

function Mostrador() {
  const userName = useContext(UserContext);
  return <p>{userName} gen</p>;
}

export default function Nombre() {
  const userName = "Martín";

  return (
    <UserContext.Provider value={userName}>
      <Mostrador />
    </UserContext.Provider>
  );
}
