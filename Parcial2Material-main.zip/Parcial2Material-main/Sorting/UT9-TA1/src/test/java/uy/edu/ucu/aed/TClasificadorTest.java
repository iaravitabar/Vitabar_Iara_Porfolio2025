package uy.edu.ucu.aed;

import static org.junit.Assert.assertNull;
import static org.junit.jupiter.api.Assertions.assertArrayEquals;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

public class TClasificadorTest {

    private static TClasificador instance;

    @BeforeAll
    public static void setUp() {
        instance = new TClasificador();
    }
    
    @Test
    void testOrdenarPorBurbuja() {

    }

    @Test
    void testOrdenarPorInsercion() {

    }

    @Test
    void testOrdenarPorShell() {

    }

     @Test
    public void testOrdenarPorInsercion_EmptyArray() {
        int[] input = {};
        int[] expected = {};
        assertArrayEquals(expected, instance.ordenarPorInsercion(input));
    }
    
    @Test
    public void testOrdenarPorInsercion_SingleElementArray() {
        int[] input = {1};
        int[] expected = {1};
        assertArrayEquals(expected, instance.ordenarPorInsercion(input));
    }
    
    @Test
    public void testOrdenarPorInsercion_AlreadySortedArray() {
        int[] input = {1, 2, 3, 4, 5};
        int[] expected = {1, 2, 3, 4, 5};
        assertArrayEquals(expected, instance.ordenarPorInsercion(input));
    }
    
    @Test
    public void testOrdenarPorInsercion_ReverseSortedArray() {
        int[] input = {5, 4, 3, 2, 1};
        int[] expected = {1, 2, 3, 4, 5};
        assertArrayEquals(expected, instance.ordenarPorInsercion(input));
    }
    
    @Test
    public void testOrdenarPorInsercion_ArrayWithDuplicates() {
        int[] input = {3, 1, 2, 3, 1};
        int[] expected = {1, 1, 2, 3, 3};
        assertArrayEquals(expected, instance.ordenarPorInsercion(input));
    }
    
    @Test
    public void testOrdenarPorInsercion_RandomOrderArray() {
        int[] input = {4, 2, 3, 1, 5};
        int[] expected = {1, 2, 3, 4, 5};
        assertArrayEquals(expected, instance.ordenarPorInsercion(input));
    }
    
    @Test
    public void testOrdenarPorInsercion_NullInput() {
        assertNull(instance.ordenarPorInsercion(null));
    }

    @Test
    public void testOrdenarPorShell_EmptyArray() {
        int[] input = {};
        int[] expected = {};
        assertArrayEquals(expected, instance.ordenarPorShell(input));
    }
    
    @Test
    public void testOrdenarPorShell_SingleElementArray() {
        int[] input = {1};
        int[] expected = {1};
        assertArrayEquals(expected, instance.ordenarPorShell(input));
    }
    
    @Test
    public void testOrdenarPorShell_AlreadySortedArray() {
        int[] input = {1, 2, 3, 4, 5};
        int[] expected = {1, 2, 3, 4, 5};
        assertArrayEquals(expected, instance.ordenarPorShell(input));
    }
    
    @Test
    public void testOrdenarPorShell_ReverseSortedArray() {
        int[] input = {5, 4, 3, 2, 1};
        int[] expected = {1, 2, 3, 4, 5};
        assertArrayEquals(expected, instance.ordenarPorShell(input));
    }
    
    @Test
    public void testOrdenarPorShell_ArrayWithDuplicates() {
        int[] input = {3, 1, 2, 3, 1};
        int[] expected = {1, 1, 2, 3, 3};
        assertArrayEquals(expected, instance.ordenarPorShell(input));
    }
    
    @Test
    public void testOrdenarPorShell_RandomOrderArray() {
        int[] input = {4, 2, 3, 1, 5};
        int[] expected = {1, 2, 3, 4, 5};
        assertArrayEquals(expected, instance.ordenarPorShell(input));
    }
    
    @Test
    public void testOrdenarPorShell_NullInput() {
        assertNull(instance.ordenarPorShell(null));
    }

    @Test
    public void testOrdenarPorBurbuja_EmptyArray() {
        int[] input = {};
        int[] expected = {};
        assertArrayEquals(expected, instance.ordenarPorBurbuja(input));
    }
    
    @Test
    public void testOrdenarPorBurbuja_SingleElementArray() {
        int[] input = {1};
        int[] expected = {1};
        assertArrayEquals(expected, instance.ordenarPorBurbuja(input));
    }
    
    @Test
    public void testOrdenarPorBurbuja_AlreadySortedArray() {
        int[] input = {1, 2, 3, 4, 5};
        int[] expected = {1, 2, 3, 4, 5};
        assertArrayEquals(expected, instance.ordenarPorBurbuja(input));
    }
    
    @Test
    public void testOrdenarPorBurbuja_ReverseSortedArray() {
        int[] input = {5, 4, 3, 2, 1};
        int[] expected = {1, 2, 3, 4, 5};
        assertArrayEquals(expected, instance.ordenarPorBurbuja(input));
    }
    
    @Test
    public void testOrdenarPorBurbuja_ArrayWithDuplicates() {
        int[] input = {3, 1, 2, 3, 1};
        int[] expected = {1, 1, 2, 3, 3};
        assertArrayEquals(expected, instance.ordenarPorBurbuja(input));
    }
    
    @Test
    public void testOrdenarPorBurbuja_RandomOrderArray() {
        int[] input = {4, 2, 3, 1, 5};
        int[] expected = {1, 2, 3, 4, 5};
        assertArrayEquals(expected, instance.ordenarPorBurbuja(input));
    }
    
    @Test
    public void testOrdenarPorBurbuja_NullInput() {
        assertNull(instance.ordenarPorBurbuja(null));
    }
}
