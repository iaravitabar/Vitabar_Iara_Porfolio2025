package Grafos;

import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

public class TGrafoDirigido implements IGrafoDirigido {

    private Map<Comparable, TVertice> vertices; // vertices del grafo.-

    public TGrafoDirigido(Collection<TVertice> vertices, Collection<TArista> aristas) {
        this.vertices = new HashMap<>();
        for (TVertice vertice : vertices) {
            insertarVertice(vertice.getEtiqueta());
        }
        for (TArista arista : aristas) {
            insertarArista(arista);
        }
    }

    /**
     * Metodo encargado de eliminar una arista dada por un origen y destino. En
     * caso de no existir la adyacencia, retorna falso. En caso de que las
     * etiquetas sean invalidas, retorna falso.
     *
     */
    public boolean eliminarArista(Comparable nomVerticeOrigen, Comparable nomVerticeDestino) {
        if ((nomVerticeOrigen != null) && (nomVerticeDestino != null)) {
            TVertice vertOrigen = buscarVertice(nomVerticeOrigen);
            if (vertOrigen != null) {
                return vertOrigen.eliminarAdyacencia(nomVerticeDestino);
            }
        }
        return false;
    }

    /**
     * Metodo encargado de verificar la existencia de una arista. Las etiquetas
     * pasadas por parámetro deben ser válidas.
     *
     * @return True si existe la adyacencia, false en caso contrario
     */
    public boolean existeArista(Comparable etiquetaOrigen, Comparable etiquetaDestino) {
        TVertice vertOrigen = buscarVertice(etiquetaOrigen);
        TVertice vertDestino = buscarVertice(etiquetaDestino);
        if ((vertOrigen != null) && (vertDestino != null)) {
            return vertOrigen.buscarAdyacencia(vertDestino) != null;
        }
        return false;
    }

    /**
     * Metodo encargado de verificar la existencia de un vertice dentro del
     * grafo.-
     *
     * La etiqueta especificada como parámetro debe ser válida.
     *
     * @param unaEtiqueta Etiqueta del vertice a buscar.-
     * @return True si existe el vertice con la etiqueta indicada, false en caso
     *         contrario
     */
    public boolean existeVertice(Comparable unaEtiqueta) {
        return getVertices().get(unaEtiqueta) != null;
    }

    /**
     * Metodo encargado de verificar buscar un vertice dentro del grafo.-
     *
     * La etiqueta especificada como parametro debe ser valida.
     *
     * @param unaEtiqueta Etiqueta del vertice a buscar.-
     * @return El vertice encontrado. En caso de no existir, retorna nulo.
     */
    public TVertice buscarVertice(Comparable unaEtiqueta) {
        return getVertices().get(unaEtiqueta);
    }

    /**
     * Metodo encargado de insertar una arista en el grafo (con un cierto
     * costo), dado su vertice origen y destino.- Para que la arista sea valida,
     * se deben cumplir los siguientes casos: 1) Las etiquetas pasadas por
     * parametros son válidas.- 2) Los vertices (origen y destino) existen
     * dentro del grafo.- 3) No es posible ingresar una arista ya existente
     * (miso origen y mismo destino, aunque el costo sea diferente).- 4) El
     * costo debe ser mayor que 0.
     *
     * @return True si se pudo insertar la adyacencia, false en caso contrario
     */
    public boolean insertarArista(TArista arista) {
        if ((arista.getEtiquetaOrigen() != null) && (arista.getEtiquetaDestino() != null)) {
            TVertice vertOrigen = buscarVertice(arista.getEtiquetaOrigen());
            TVertice vertDestino = buscarVertice(arista.getEtiquetaDestino());
            if ((vertOrigen != null) && (vertDestino != null)) {
                return vertOrigen.insertarAdyacencia(arista.getCosto(), vertDestino);
            }
        }
        return false;
    }

    /**
     * Metodo encargado de insertar un vertice en el grafo.
     *
     * No pueden ingresarse vertices con la misma etiqueta. La etiqueta
     * especificada como parámetro debe ser válida.
     *
     * @param unaEtiqueta Etiqueta del vertice a ingresar.
     * @return True si se pudo insertar el vertice, false en caso contrario
     */
    public boolean insertarVertice(Comparable unaEtiqueta) {
        if ((unaEtiqueta != null) && (!existeVertice(unaEtiqueta))) {
            TVertice vert = new TVertice(unaEtiqueta);
            getVertices().put(unaEtiqueta, vert);
            return getVertices().containsKey(unaEtiqueta);
        }
        return false;
    }

    @Override

    public boolean insertarVertice(TVertice vertice) {
        Comparable unaEtiqueta = vertice.getEtiqueta();
        if ((unaEtiqueta != null) && (!existeVertice(unaEtiqueta))) {
            getVertices().put(unaEtiqueta, vertice);
            return getVertices().containsKey(unaEtiqueta);
        }
        return false;
    }

    public Object[] getEtiquetasOrdenado() {
        TreeMap<Comparable, TVertice> mapOrdenado = new TreeMap<>(this.getVertices());
        return mapOrdenado.keySet().toArray();
    }

    /**
     * @return the vertices
     */
    public Map<Comparable, TVertice> getVertices() {
        return vertices;
    }

    @Override
    public Comparable centroDelGrafo() {
        Object[] etiquetasVertices = vertices.keySet().toArray();
        String centro_del_grafo;
        TreeMap<Comparable, Comparable> ex = new TreeMap<>();
        for (Object object : etiquetasVertices) {
            ex.put(obtenerExcentricidad((Comparable) object), (Comparable) object);
        }

        return ex.get(ex.firstKey());
    }

    @Override
    public Double[][] floyd() {
        Double[][] C = UtilGrafos.obtenerMatrizCostos(vertices);
        int largo = C.length;
        Double[][] A = new Double[largo][largo];
        Integer[][] P = new Integer[largo][largo];

        for (int i = 0; i < C.length; i++) {
            for (int j = 0; j < C.length; j++ ) {
                A[i][j] = C[i][j];
                P[i][j] = 0;
            }
        }

        for (int k = 0; k < C.length; k++) {
            for (int i = 0; i < C.length; i++) {
                for (int j = 0; j < C.length; j++) {
                    if (A[i][k] + A[k][j] < A[i][j]) {
                        A[i][j] = A[i][k] + A[k][j];
                        P[i][j] = k;
                    }
                }
            }
        }

        return A;
    }

    @Override
    public Comparable obtenerExcentricidad(Comparable etiquetaVertice) {
        Double[][] floyd = floyd();
        Object[] arrayVertices = vertices.keySet().toArray();
        int index = 0;
        for (int i = 0; i < arrayVertices.length; i++) {
            if (etiquetaVertice.equals(arrayVertices[i])) {
                index = i;
                break;
            }
        }

        Double ex = 0.0;
        for (int i = 0; i < arrayVertices.length; i++) {
            if (floyd[i][index] > ex)
                ex = floyd[i][index];
        }

        return ex;
    }

    @Override
    public boolean[][] warshall() {
        boolean[][] C = UtilGrafos.obtenerMatrizBoolean(vertices);

        Object[] etiquetasVertices = vertices.keySet().toArray();
        boolean[][] A = new boolean[etiquetasVertices.length][etiquetasVertices.length];

        for (int i = 0; i < C.length; i++) {
            for (int j = 0; j < C.length; j++) {
                A[i][j] = C[i][j];
            }
        }
        for (int k = 0; k < C.length; k++) {
            for (int i = 0; i < C.length; i++) {
                for (int j = 0; j < C.length; j++) {
                    if (A[i][j] == false)
                        A[i][j] = A[i][k] && A[k][j];
                }
            }
        }
        return A;
    }

    public Map<Comparable, Double> dijkstra(Comparable etiquetaOrigen) {
        Set<TVertice> noVisitados = new HashSet<>(vertices.values());

        Map<Comparable, Double> distancias = new HashMap<>();
        for (TVertice vertice : vertices.values()) {
            distancias.put(vertice.getEtiqueta(), Double.POSITIVE_INFINITY);
        }
        distancias.put(etiquetaOrigen, 0.0);

        while (!noVisitados.isEmpty()) {
            TVertice v = null;
            for (TVertice vertice : noVisitados) {
                if (v == null || distancias.get(vertice.getEtiqueta()) < distancias.get(v.getEtiqueta())) {
                    v = vertice;
                }
            }

            noVisitados.remove(v);

            for (Object adyacente : v.getAdyacentes()) {
                TVertice w = ((TAdyacencia) adyacente).getDestino();
                double peso = ((TAdyacencia) adyacente).getCosto();
                double distanciaHastaV = distancias.get(v.getEtiqueta());
                double distanciaPropuesta = distanciaHastaV + peso;
                if (distanciaPropuesta < distancias.get(w.getEtiqueta())) {
                    distancias.put(w.getEtiqueta(), distanciaPropuesta);
                }
            }
        }

        return distancias;
    }

    @Override
    public boolean eliminarVertice(Comparable nombreVertice) {
        throw new UnsupportedOperationException("Not supported yet."); // To change body of generated methods, choose
                                                                       // Tools | Templates.
    }

    @Override
    public Collection<TVertice> bpf() {
        LinkedList<TVertice> visitados = new LinkedList<>();

        vertices.forEach((k, v) -> {
            if (!v.getVisitado()) {
                v.bpf(visitados);
            }
        });

        return visitados;
    }

    @Override
    public Collection<TVertice> bpf(Comparable etiquetaOrigen) {
        if (!existeVertice(etiquetaOrigen))
            return null;

        /* Instanciamos los valores iniciales para poder llamar el método de TVertice */
        TVertice v_origen = buscarVertice(etiquetaOrigen);
        LinkedList<TVertice> visitados = new LinkedList<>();

        v_origen.bpf(visitados);

        return visitados;
    }

    @Override
    public Collection<TVertice> bpf(TVertice vertice) {
        if (!vertices.containsValue(vertice))
            return null;

        /* Instanciamos los valores iniciales para poder llamar el método de TVertice */
        LinkedList<TVertice> visitados = new LinkedList<>();

        vertice.bpf(visitados);

        return visitados;
    }

    @Override
    public void desvisitarVertices() {
        vertices.forEach((k, v) -> v.setVisitado(false));
    }

    @Override
    public TCaminos todosLosCaminos(Comparable etiquetaOrigen, Comparable etiquetaDestino) {
        if (!existeVertice(etiquetaOrigen) || !existeVertice(etiquetaDestino))
            return null;
        desvisitarVertices();

        /* Instanciamos los valores iniciales para poder llamar el método de TVertice */
        TVertice v_origen = buscarVertice(etiquetaOrigen);
        TCaminos caminos = new TCaminos();
        TCamino camino_inicial = new TCamino(v_origen);

        return v_origen.todosLosCaminos(etiquetaDestino, camino_inicial, caminos);
    }

    @Override
    public boolean tieneCiclo() {
        desvisitarVertices();
        Set<TVertice> camino = new HashSet<>();

        for (TVertice vertice : vertices.values()) {
            if (vertice.getVisitado())
                continue;

            boolean ciclo = vertice.tieneCiclo_TGrafoDirigido(camino);
            if (ciclo == true)
                return ciclo;
        }

        return false;
    }

    @Override
    public boolean tieneCiclo(Comparable etiquetaOrigen) {
        if (!existeVertice(etiquetaOrigen))
            return false;
        desvisitarVertices();
        /* Instanciamos los valores iniciales para poder llamar el método de TVertice */
        TVertice v_origen = buscarVertice(etiquetaOrigen);
        Set<TVertice> camino = new HashSet<>();

        return v_origen.tieneCiclo_TGrafoDirigido(camino);
    }

    @Override
    public boolean tieneCiclo(TVertice vertice) {
        if (!vertices.containsValue(vertice))
            return false;
        desvisitarVertices();

        /* Instanciamos los valores iniciales para poder llamar el método de TVertice */
        Set<TVertice> camino = new HashSet<>();

        return vertice.tieneCiclo_TGrafoDirigido(camino);
    }

    @Override
    public void clasificarArcos(List<TArista> a_arbol, List<TArista> a_avance,
            List<TArista> a_cruzado, List<TArista> a_retroceso) {
        desvisitarVertices();
        for (TVertice vertice : vertices.values()) {
            if (vertice.getVisitado())
                continue;   //Cubris todos los componentes del grafo. 

            Set<TVertice> camino = new HashSet<>();
            vertice.clasificarArcos_GrafoDirigido(a_arbol, a_avance, a_cruzado, a_retroceso, camino, 0); 
        }
    }

    @Override
    public void clasificarArcos(Comparable etiquetaOrigen, List<TArista> a_arbol, List<TArista> a_avance,
            List<TArista> a_cruzado, List<TArista> a_retroceso) {
        TVertice v_origen = buscarVertice(etiquetaOrigen);
        //ESTE COMPOPNENTE CONEXO T INTERESA
        desvisitarVertices();
        if (v_origen == null)
            return;
        Set<TVertice> camino = new HashSet();
        v_origen.clasificarArcos_GrafoDirigido(a_arbol, a_avance, a_cruzado, a_retroceso, camino, 0);
    }

    @Override
    public void clasificarArcos(TVertice vertice, List<TArista> a_arbol, List<TArista> a_avance,
            List<TArista> a_cruzado, List<TArista> a_retroceso) {
                //ESTE COMPOPNENTE CONEXO T INTERESA
        desvisitarVertices();
        if (!vertices.containsValue(vertice))
            return;
        Set<TVertice> camino = new HashSet();
        vertice.clasificarArcos_GrafoDirigido(a_arbol, a_avance, a_cruzado, a_retroceso, camino, 0);
    }

    @Override
    public List<TVertice> ordenacionTopologica() {
        if (tieneCiclo())
            return null;
        desvisitarVertices();

        List<TVertice> ord = new LinkedList<>();
        for (TVertice vertice : vertices.values()) {
            if (!vertice.getVisitado())
                vertice.ordenacionTopologica(ord);
        }

        return ord;
    }

    //Hacer un recorrido. Sisema de previaturas. Le das un orden lineal al grafo segun los nodos previos al nodo que tenes. Los nodos que tienen una flecha apuntando hacia vos.
    //es como invertir flechas y lo transformas en una lista. Tengo nodo1 apunta a nodo2 y apunta a nodo3 y apunta a nodo4. ordenaciontopologica: 4-3-2-1. 

    @Override
    public List<TVertice> ordenacionTopologica(Comparable etiqueta) {
        if (tieneCiclo())
            return null;

        desvisitarVertices();

        TVertice v_origen = buscarVertice(etiqueta);
        if (v_origen == null)
            return null;

        List<TVertice> ord = new LinkedList<>();
        v_origen.ordenacionTopologica(ord);

        for (TVertice vertice : vertices.values()) {
            if (!vertice.getVisitado())
                vertice.ordenacionTopologica(ord);
        }

        return ord;
    }

    @Override
    public List<TVertice> ordenacionTopologica(TVertice vertice) {
        if (tieneCiclo())
            return null;

        desvisitarVertices();

        if (!vertices.containsValue(vertice))
            return null;

        List<TVertice> ord = new LinkedList<>();
        vertice.ordenacionTopologica(ord);

        for (TVertice vertice2 : vertices.values()) {
            if (!vertice2.getVisitado())
                vertice2.ordenacionTopologica(ord);
        }

        return ord;
    }

    public boolean esConexo() {
        desvisitarVertices();
        LinkedList<Comparable> claves = new LinkedList<>(getVertices().keySet());

        TVertice random = getVertices().get(claves.get(0));

        desvisitarVertices();
        return random.bea().size() == getVertices().size();
    }
}