package Grafos;

import java.util.Collection;

import java.util.LinkedList;
import java.util.Random;

public class TAristas extends LinkedList<TArista> {

    private final static String SEPARADOR_ELEMENTOS_IMPRESOS = "-";
    //private Collection<TArista> aristas  = new LinkedList<TArista>();

    /**
     * Busca dentro de la lista de aristas una arista que conecte a etOrigen con
     * etDestino
     *
     * @param etOrigen
     * @param etDestino
     * @return
     */
    public TArista buscar(Comparable etOrigen, Comparable etDestino) {
        for (TArista laa : this) {
            if ((laa.getEtiquetaOrigen().equals(etOrigen)) && laa.getEtiquetaDestino().equals(etDestino)) {
                return laa;
            }
        }

        return null;
    }

    /**
     * Busca la arista de menor costo que conecte a cualquier nodo de VerticesU
     * con cualquier otro de VerticesV y cuyo costo sea el minimo
     *
     * @param VerticesU - Lista de vertices U
     * @param VerticesV - Lista de vertices V
     * @return
     */
    public TArista buscarMin(Collection<Comparable> VerticesU, Collection<Comparable> VerticesV) {
        TArista tempArista;
        TArista tAMin = null;
        Double costoMin = Double.POSITIVE_INFINITY;

        for (Comparable u : VerticesU) {
            for (Comparable v : VerticesV) {
                tempArista = buscar(u, v);
                if (tempArista != null) {
                    if (tempArista.getCosto() < costoMin) {
                        costoMin = tempArista.getCosto();
                        tAMin = tempArista;
                    }
                }
            }
        }
        return tAMin;
    }

    public String imprimirEtiquetas() {
        if (this.isEmpty()) {
            return null;
        }
        StringBuilder salida = new StringBuilder();
        //TODO: Completar codigo que imprime todas las aristas de la lista en el siguiente formato:
        //ORIGEN - DESTINO - COSTO
        return salida.toString();
    }

    void insertarAmbosSentidos(Collection<TArista> aristas) {
        TArista tempArista;
        for (TArista ta : aristas) {
            this.add(ta);
            this.add(ta.aristaInversa());
        }
    }

    protected TArista[] ordenarPorQuickSort() {
        TArista[] aux = new TArista[this.size()];
        int contador = 0;
        for(TArista arista : this){
            aux[contador] = arista;
            contador++;
        }

		quicksort(aux, 0, this.size() - 1);
		return aux;
	}
	
	private void quicksort(TArista[] entrada, int i, int j) {
		int izquierda = i;
		int derecha = j;

		int posicionPivote = encuentraPivote(izquierda,derecha,entrada);
		if (posicionPivote >= 0){
			TArista pivote = entrada[posicionPivote];  
			while (izquierda <= derecha) {
				while ((entrada[izquierda].getCosto() < pivote.getCosto()) && (izquierda < j)) {
					izquierda++; 
				}

				while ((pivote.getCosto() < entrada[derecha].getCosto()) && (derecha > i)) {
					derecha--; 
				}

				if (izquierda <= derecha) {
					intercambiar(entrada, derecha, izquierda); 
					izquierda++;
					derecha--;
				}
			}

			if (i < derecha) {
                quicksort(entrada, i, derecha);
            }
            if (izquierda < j) {
                quicksort(entrada, izquierda, j); 
            }
		}
	}

	private int encuentraPivote(int Left,int Right, TArista[] entrada){
        Random random = new Random();
        return random.nextInt(Right-Left +1) + Left;
    }
    private void intercambiar(TArista[] vector, int pos1, int pos2) {
		TArista temp = vector[pos2];
		vector[pos2] = vector[pos1];
		vector[pos1] = temp;
	}

}
