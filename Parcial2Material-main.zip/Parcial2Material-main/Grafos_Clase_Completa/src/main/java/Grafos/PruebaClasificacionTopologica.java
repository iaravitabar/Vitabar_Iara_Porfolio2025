package Grafos;
import java.util.ArrayList;
import java.util.List;

public class PruebaClasificacionTopologica {
    public static void main(String[] args) {
        TGrafoDirigido gnd = (TGrafoDirigido) UtilGrafos.cargarGrafo("ClasTopV.txt", "ClasTopA.txt",
                    false, TGrafoDirigido.class);

        List<TVertice> ordenacionResultado = gnd.ordenacionTopologica("C2");
        for(TVertice v : ordenacionResultado){
            System.out.println(v.getEtiqueta());
        }
    }
}
