package Grafos;

import java.util.LinkedList;
import java.util.List;

public class PruebaGrafoUT7_PD8 {
    public static void main(String[] args) {
        TGrafoDirigido gd = (TGrafoDirigido) UtilGrafos.cargarGrafo("./src/vertices_clasificarArcos.txt",
                "./src/aristas_clasificarArcos.txt",
                false, TGrafoDirigido.class);

        List<TArista> a_arbol = new LinkedList<>();
        List<TArista> a_avance = new LinkedList<>();
        List<TArista> a_cruzado = new LinkedList<>();
        List<TArista> a_retroceso = new LinkedList<>();

        gd.desvisitarVertices();
        gd.clasificarArcos(a_arbol, a_avance, a_cruzado, a_retroceso);

        System.out.println("Arcos de árbol:");
        for (TArista elem : a_arbol) {
            System.out.println("\t" + elem.getEtiquetaOrigen() + "->" + elem.getEtiquetaDestino());
        }

        System.out.println("Arcos de avance:");
        for (TArista elem : a_avance) {
            System.out.println("\t" + elem.getEtiquetaOrigen() + "->" + elem.getEtiquetaDestino());
        }

        System.out.println("Arcos cruzados:");
        for (TArista elem : a_cruzado) {
            System.out.println("\t" + elem.getEtiquetaOrigen() + "->" + elem.getEtiquetaDestino());
        }

        System.out.println("Arcos de retroceso:");
        for (TArista elem : a_retroceso) {
            System.out.println("\t" + elem.getEtiquetaOrigen() + "->" + elem.getEtiquetaDestino());
        }

        // Incluye un poquito del PD5
        System.out.println("¿Hay ciclos en el grafo?");
        gd.desvisitarVertices();
        System.out.println("\t" + gd.tieneCiclo());

        System.out.println("Sort topológico:");
        // Va a devolver null, porque el grafo tiene ciclos.
        gd.desvisitarVertices();
        System.out.println("\t" + gd.ordenacionTopologica());

        System.out.println("¿Es fuertemente conexo?");
        gd.desvisitarVertices();
        System.out.println("\t" + gd.esConexo());

        UtilGrafos.imprimirMatrizMejorado(UtilGrafos.warshalImprimible(gd.warshall()), gd.getVertices(),"Warshall");


    }
}
