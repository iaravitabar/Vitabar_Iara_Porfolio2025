package Grafos;

import java.util.Collection;

public class PruebaGrafoUT7_PD3 {

    public static void main(String[] args) {
        TGrafoDirigido gd = (TGrafoDirigido) UtilGrafos.cargarGrafo("./src/aeropuertos.txt", "./src/conexiones.txt",
                false, TGrafoDirigido.class);

        Object[] etiquetasarray = gd.getEtiquetasOrdenado();

        Double[][] matriz = UtilGrafos.obtenerMatrizCostos(gd.getVertices());
        UtilGrafos.imprimirMatrizMejorado(matriz, gd.getVertices(), "Matriz");
        Double[][] mfloyd = gd.floyd();
        UtilGrafos.imprimirMatrizMejorado(mfloyd, gd.getVertices(), "Matriz luego de FLOYD");
        for (int i = 0; i < etiquetasarray.length; i++) {
            System.out.println("excentricidad de " + etiquetasarray[i] + " : "
                    + gd.obtenerExcentricidad((Comparable) etiquetasarray[i]));
        }
        System.out.println();
        System.out.println("Centro del grafo: " + gd.centroDelGrafo());

        System.out.println("\nBPF desde Montevideo:");
        gd.desvisitarVertices();
        Collection<TVertice> recorrido_Montevideo = gd.bpf("Montevideo");
        // imprimir etiquetas del bpf desde Asunción....
        for (TVertice etVert : recorrido_Montevideo) {
            System.out.print(etVert.getEtiqueta() + " ");
        }

        boolean boo = true;
        for (TVertice vertice : gd.getVertices().values()) {
            if (!vertice.getVisitado()) {
                boo = false;
                break;
            }
        }
        System.out.println("\nSe visitaron todos los vértices? " + boo);

        System.out.println("\nRecorridos desde Montevideo a Rio");
        gd.desvisitarVertices(); // Muy importante desvisitar todo
        TCaminos caminos = gd.todosLosCaminos("Montevideo", "Rio_de_Janeiro");
        caminos.imprimirCaminosConsola();
        // boolean[][] mwarshall = gd.warshall();
        // UtilGrafos.imprimirMatrizMejorado(UtilGrafos.warshalImprimible(mwarshall),
        // gd.getVertices(),"Warshall");

    }
}
