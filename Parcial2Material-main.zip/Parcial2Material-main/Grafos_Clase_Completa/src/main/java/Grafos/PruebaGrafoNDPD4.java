package Grafos;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

public class PruebaGrafoNDPD4 {
    public static void main(String[] args) {
        TGrafoDirigido gnd = (TGrafoDirigido) UtilGrafos.cargarGrafo("UT8_PD4_VERTICES.TXT", "UT8_PD4_ARISTAS.TXT",
                    false, TGrafoDirigido.class);



        List<TArista> lista = new ArrayList<>();
        //System.out.println("Breakpoint");

        LinkedList<TVertice> l = (LinkedList<TVertice>) gnd.ordenacionTopologica();
        for(TVertice v : l)
            System.out.println(v.getEtiqueta());
    }
}
