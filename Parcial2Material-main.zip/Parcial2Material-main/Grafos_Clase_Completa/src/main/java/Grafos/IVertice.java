package Grafos;

import java.util.Collection;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;
import java.util.Stack;

public interface IVertice {

        TAdyacencia buscarAdyacencia(TVertice verticeDestino);

        TAdyacencia buscarAdyacencia(Comparable etiquetaDestino);

        boolean eliminarAdyacencia(Comparable nomVerticeDestino);

        LinkedList<TAdyacencia> getAdyacentes();

        boolean insertarAdyacencia(Double costo, TVertice verticeDestino);

        Double obtenerCostoAdyacencia(TVertice verticeDestino);

        TVertice primerAdyacente();

        TVertice siguienteAdyacente(TVertice w);

        public void bpf(Collection<TVertice> visitados);

        public TCaminos todosLosCaminos(Comparable etVertDest, TCamino caminoPrevio, TCaminos todosLosCaminos);

        public void bea(Collection<TVertice> visitados);

        public boolean tieneCiclo_TGrafoDirigido(Set<TVertice> pila);

        public boolean tieneCiclo_TGrafoNoDirigido(Stack<TVertice> pila, TVertice padre);

        public void clasificarArcos_GrafoDirigido(List<TArista> a_arbol, List<TArista> a_avance,
                        List<TArista> a_cruzado, List<TArista> a_retroceso, Set<TVertice> camino, int numeracion);

        public void clasificarArcos_GrafoNoDirigido(List<TArista> a_arbol, List<TArista> a_retroceso, TVertice anterior);

        public void ordenacionTopologica(List<TVertice> ordenacion);

        boolean conectadoCon(TVertice destino);

        public LinkedList<TVertice> bea();
}