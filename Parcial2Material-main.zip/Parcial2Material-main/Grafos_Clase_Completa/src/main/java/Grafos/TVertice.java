package Grafos;

import java.util.Collection;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;
import java.util.Set;
import java.util.Stack;

public class TVertice<T> implements IVertice {
    private final Comparable etiqueta;
    private LinkedList<TAdyacencia> adyacentes;
    private boolean visitado;
    private T datos;

    private int num_bpf;
    private int num_bp;
    private int num_bajo;

    public int getNum_bpf() {
        return num_bpf;
    }
    public int getNum_bp() {
        return num_bp;
    }
    public int getNum_bajo() {
        return num_bajo;
    }

    public void setNum_bpf(int num_bpf) {
        this.num_bpf = num_bpf;
    }

    public Comparable getEtiqueta() {
        return etiqueta;
    }

    public T getDatos() {
        return datos;
    }

    public TVertice(Comparable unaEtiqueta) {
        this.etiqueta = unaEtiqueta;
        adyacentes = new LinkedList();
        visitado = false;
    }

    public void setVisitado(boolean valor) {
        this.visitado = valor;
    }

    public boolean getVisitado() {
        return this.visitado;
    }

    @Override
    public LinkedList<TAdyacencia> getAdyacentes() {
        return adyacentes;
    }

    @Override
    public TAdyacencia buscarAdyacencia(TVertice verticeDestino) {
        if (verticeDestino != null) {
            return buscarAdyacencia(verticeDestino.getEtiqueta());
        }
        return null;
    }

    @Override
    public Double obtenerCostoAdyacencia(TVertice verticeDestino) {
        TAdyacencia ady = buscarAdyacencia(verticeDestino);
        if (ady != null) {
            return ady.getCosto();
        }
        return Double.MAX_VALUE;
    }

    @Override
    public boolean insertarAdyacencia(Double costo, TVertice verticeDestino) {
        if (buscarAdyacencia(verticeDestino) == null) {
            TAdyacencia ady = new TAdyacencia(costo, verticeDestino);
            return adyacentes.add(ady);
        }
        return false;
    }

    @Override
    public boolean eliminarAdyacencia(Comparable nomVerticeDestino) {
        TAdyacencia ady = buscarAdyacencia(nomVerticeDestino);
        if (ady != null) {
            adyacentes.remove(ady);
            return true;
        }
        return false;
    }

    @Override
    public TVertice primerAdyacente() {
        if (this.adyacentes.getFirst() != null) {
            return this.adyacentes.getFirst().getDestino();
        }
        return null;
    }

    @Override
    public TVertice siguienteAdyacente(TVertice w) {
        TAdyacencia adyacente = buscarAdyacencia(w.getEtiqueta());
        int index = adyacentes.indexOf(adyacente);
        if (index + 1 < adyacentes.size()) {
            return adyacentes.get(index + 1).getDestino();
        }
        return null;
    }

    @Override
    public TAdyacencia buscarAdyacencia(Comparable etiquetaDestino) {
        for (TAdyacencia adyacencia : adyacentes) {
            if (adyacencia.getDestino().getEtiqueta().compareTo(etiquetaDestino) == 0) {
                return adyacencia;
            }
        }
        return null;
    }

    @Override
    public void bpf(Collection<TVertice> visitados) {
        setVisitado(true);
        visitados.add(this);
        for (TAdyacencia adyacente : adyacentes) {
            TVertice vertAdy = adyacente.getDestino();
            if (!vertAdy.getVisitado()) {
                vertAdy.bpf(visitados);
            }
        }
    }

    @Override
    public TCaminos todosLosCaminos(Comparable etVertDest, TCamino caminoPrevio, TCaminos todosLosCaminos) {
        this.setVisitado(true);
        for (TAdyacencia adyacencia : this.getAdyacentes()) {
            TVertice destino = adyacencia.getDestino();
            if (!destino.getVisitado()) {
                if (destino.getEtiqueta().compareTo(etVertDest) == 0) {
                    TCamino copia = caminoPrevio.copiar();
                    copia.agregarAdyacencia(adyacencia);
                    todosLosCaminos.addCamino(copia);
                } else {
                    caminoPrevio.agregarAdyacencia(adyacencia);
                    destino.todosLosCaminos(etVertDest, caminoPrevio, todosLosCaminos);
                    caminoPrevio.eliminarAdyacencia(adyacencia);
                }
            }
        }
        this.setVisitado(false);
        return todosLosCaminos;
    }

    @Override
    public void bea(Collection<TVertice> visitados) {
        Queue<TVertice> cola = new LinkedList<>();
        this.setVisitado(true);
        cola.add(this);
        visitados.add(this);
        while (!cola.isEmpty()) {
            TVertice verticeActual = cola.remove();
            LinkedList<TAdyacencia> adyacentesActual = verticeActual.getAdyacentes();
            for (TAdyacencia adyacencia : adyacentesActual) {
                TVertice adyacente = adyacencia.getDestino();
                if (!adyacente.getVisitado()) {
                    adyacente.setVisitado(true);
                    cola.add(adyacente);
                    visitados.add(adyacente);
                }
            }
        }
    }

    @Override
    public LinkedList<TVertice> bea() { 
        LinkedList<TVertice> retorno = new LinkedList<>(); 
        Queue<TVertice> cola = new LinkedList<>();

        this.visitado = true;
        cola.add(this);
        retorno.add(this);

        while(!cola.isEmpty()){
            TVertice x = cola.remove();
            for(Object y : x.getAdyacentes()){
                TAdyacencia j = (TAdyacencia)y;
                TVertice v = j.getDestino();
                if(!v.visitado){
                    v.setVisitado(true);
                    cola.add(v);
                    retorno.add(v);
                }
            }
        }
        return retorno;
    }

    @Override
    public boolean conectadoCon(TVertice destino) {
        Queue<TVertice> cola = new LinkedList<>();

        cola.add(this);
        this.visitado = true;
        while(!cola.isEmpty()){
            TVertice x = cola.remove();
            for(Object y : x.getAdyacentes()){
                TAdyacencia j = (TAdyacencia)y;
                TVertice v = j.getDestino();
                if(!v.visitado){
                    v.setVisitado(true);
                    if(v == destino)
                        return true;
                    cola.add(v);
                }
            }
        }
        return false;
        
    }

    @Override
    public boolean tieneCiclo_TGrafoDirigido(Set<TVertice> camino) {
        setVisitado(true);
        camino.add(this); // Agregamos el vértice al camino.
        for (TAdyacencia adyacente : adyacentes) {
            TVertice vertAdy = adyacente.getDestino();
            if (!vertAdy.getVisitado()) {
                boolean boo = vertAdy.tieneCiclo_TGrafoDirigido(camino);
                if (boo)
                    return true;
            } else if (camino.contains(vertAdy) && !this.equals(vertAdy))
                // Entra si el adyacente ya estaba en el camino y además es diferente al vértice
                // actual (Bucle != Ciclo). Flecha que se apunta a si mismo. 
                //si cumple la condicion es que dio una vuelta, ciclo. 
                return true;
        }
        camino.remove(this); // Quitamos el vértice del camino.
        return false;
    }

    @Override
    public boolean tieneCiclo_TGrafoNoDirigido(Stack<TVertice> pila, TVertice padre) {
        setVisitado(true);
        pila.push(this); // Agregamos este vértice al camino.
        for (TAdyacencia adyacente : adyacentes) {
            TVertice vertAdy = adyacente.getDestino();
            if (!vertAdy.getVisitado()) {
                boolean boo = vertAdy.tieneCiclo_TGrafoNoDirigido(pila, this);
                if (boo)
                    return true;
            } else if (pila.contains(vertAdy) && !this.equals(vertAdy) && !vertAdy.equals(padre)) {
                // Entra si el adyacente ya estaba en el camino y además es diferente al vértice
                // actual (Bucle != Ciclo). Flecha que se apunta a si mismo. 
                // Además, como el grafo no es dirigido, las referencias siempre van para los
                // dos lados.
                // Eso no cuenta como ciclo. Por eso que no sea igual que el padre.
                return true;
            }
        }

        pila.pop(); // Quitamos el vértice del camino.
        return false;
    }

    /*
     * Cuando sale de la recursion lo saca del camino. O sea arranca en A llega a C, cuando sale de C, no hay mas desendientes, saca a C
     * del camino, xq ya no es la continuacion desde A. En los arcos cruzados nunca va a estar en el camino, xq no son ni desendientes ni antecesores.
     * En el caso que idee yo de c-d. c->d es de arbol, xq D nunca habia sido descubierto, pero una vez ya fue descubierto, tan solo es otra forma de llegar partiendo de A
     * eso es un arco de avance. No descubris un vertice nuevo para el bosque abarcador pero si es otra forma de llegar al vertice
     * En el caso original de D->C, ahi es distinto xq C ya se habia explorado antes y los dos tienen el mismo padre. Algo asi. Es medio raro
     * Es importante ver el numero bpf y seguir la logica del codigo. Si el bpf es menor q el destino es de avance. 
     * Pero si es mayor y no esta en el camino, xq si no seria de retroceso, es cruzado. 
     * En el caso que puse yo seria cruzado si D ya hubiera sido visitado antes. Como no lo fue es de arbol nomas, xq el bpf de C es menor.
     */
    @Override
    public void clasificarArcos_GrafoDirigido(List<TArista> a_arbol, List<TArista> a_avance,
            List<TArista> a_cruzado, List<TArista> a_retroceso, Set<TVertice> camino, int numeracion) {
        setVisitado(true);
        setNum_bpf(numeracion);
        camino.add(this);
        for (TAdyacencia ady : adyacentes) {
            // Recreamos la arista que une ambos vértices
            TArista arista = new TArista(this.etiqueta, ady.getDestino().getEtiqueta(), ady.getCosto());

            // Vemos donde la guardamos
            if (!ady.getDestino().getVisitado()) {
                a_arbol.add(arista);
                ady.getDestino().clasificarArcos_GrafoDirigido(a_arbol, a_avance, a_cruzado, a_retroceso, camino,
                        numeracion + 1);
            } else {
                if (getNum_bpf() < ady.getDestino().getNum_bpf()) {
                    a_avance.add(arista);
                    continue;
                }

                if (getNum_bpf() > ady.getDestino().getNum_bpf() && camino.contains(ady.getDestino())) {
                    a_retroceso.add(arista);
                    continue;
                }

                if (getNum_bpf() > ady.getDestino().getNum_bpf() && !camino.contains(ady.getDestino())) {   //sI EL num de bpf es menor
                    a_cruzado.add(arista);
                }
            }
        }
        camino.remove(this);
    }

    //BPF
    public void clasificarArcos_GrafoNoDirigido(List<TArista> a_arbol, List<TArista> a_retroceso, TVertice anterior) {

        setVisitado(true);
    
        for (TAdyacencia ady : adyacentes) {
            TVertice destino = ady.getDestino();
            TArista arista = new TArista(this.etiqueta, destino.getEtiqueta(), ady.getCosto());
            TArista aristaInversa = new TArista(destino.getEtiqueta(), this.etiqueta, ady.getCosto());
    
            if (!destino.getVisitado()) {
                a_arbol.add(arista);
                a_arbol.add(aristaInversa);
                destino.clasificarArcos_GrafoNoDirigido(a_arbol, a_retroceso, this);
            } else if (!destino.equals(anterior)) {
                a_retroceso.add(arista);
            }
        }
    }

    @Override
    public void ordenacionTopologica(List<TVertice> ordenacion) {
        setVisitado(true);
        for (TAdyacencia ady : adyacentes) {
            if (!ady.getDestino().getVisitado()) {
                ady.getDestino().ordenacionTopologica(ordenacion);
            }
        }
        ordenacion.add(this);
    }

    public LinkedList puntosDeArticulacionGND(LinkedList<TVertice<T>> articulacion, int[] contador, TVertice anterior){
        contador[0] = contador[0] + 1;
        this.visitado = true;
        this.num_bp = contador[0];
        this.num_bajo = contador[0];

        int aux = 0;

        LinkedList<TVertice<T>> hijos = new LinkedList<>();
        for(TAdyacencia ady : this.getAdyacentes()){
            TVertice<T> v = ady.getDestino();
            hijos.add(v);
            if(!v.visitado){
                v.puntosDeArticulacionGND(articulacion, contador, this);
                aux = Math.min(this.num_bp, v.getNum_bajo());  // NUMERO BP DEL ANTERIOR.
                this.num_bajo = Math.min(this.num_bajo, aux);
            }
            else{
                if(v != anterior){ //El anterior no cuenta a la hora de setear el bajo.
                    aux = Math.min(this.num_bp, v.num_bajo);  // NUMERO BP DEL ANTERIOR. 
                    this.num_bajo = Math.min(this.num_bajo, aux);
                }

            }
        }
        if(this.num_bp > 1){
            for(TVertice<T> vertice : hijos){
                if(vertice.getNum_bajo() >= this.num_bp){
                    articulacion.add(this);
                }
            }
        }
        else{
            if(hijos.size() > 1){
                articulacion.add(this);
            }
        }
        return articulacion;

    }
    //Con C N es mi hijo, entonces tiene que ser tomado en cuenta.
    //
    
}



  /* 
    @Override
    public void clasificarArcos_GrafoNoDirigido(List<TArista> a_arbol, List<TArista> a_avance,
            List<TArista> a_cruzado, List<TArista> a_retroceso, Stack<TVertice> camino,
            int numeracion) {
        setVisitado(true);
        setNum_bpf(numeracion);
        camino.push(this);
        for (TAdyacencia ady : adyacentes) {
            // Recreamos la arista que une ambos vértices
            TArista arista = new TArista(this.etiqueta, ady.getDestino().getEtiqueta(), ady.getCosto());

            // Vemos donde la guardamos
            if (!ady.getDestino().getVisitado()) {
                a_arbol.add(arista);
                ady.getDestino().clasificarArcos_GrafoNoDirigido(a_arbol, a_avance, a_cruzado, a_retroceso, camino,
                        numeracion + 1);
            } else {
                if (getNum_bpf() < ady.getDestino().getNum_bpf()) {
                    a_avance.add(arista);
                    continue;
                }

                if (getNum_bpf() > ady.getDestino().getNum_bpf() && camino.contains(ady.getDestino())) {
                    a_retroceso.add(arista);
                    continue;
                }

                if (getNum_bpf() > ady.getDestino().getNum_bpf() && !camino.contains(ady.getDestino())) {
                    a_cruzado.add(arista);
                }
            }
        }
        camino.pop();
    }*/