package Grafos;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

public class PruebaGrafoNDPD2 {
    public static void main(String[] args) {
        TGrafoNoDirigido gnd = (TGrafoNoDirigido) UtilGrafos.cargarGrafo("verticesBEA.txt", "aristasBEA.txt",
                    false, TGrafoNoDirigido.class);



        List<TArista> lista = new ArrayList<>();
        TGrafoNoDirigido gndPrim = gnd.Prim(lista);
        TGrafoNoDirigido gndKruskal = gnd.Kruskal();
        LinkedList lol = (LinkedList) gnd.bea();
        System.out.println("Breakpoint");
        
    }

}
