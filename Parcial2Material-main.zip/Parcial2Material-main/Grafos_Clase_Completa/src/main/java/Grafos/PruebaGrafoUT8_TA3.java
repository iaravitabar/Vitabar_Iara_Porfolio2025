package Grafos;

import java.util.Collection;

public class PruebaGrafoUT8_TA3 {
    public static void main(String[] args) {
        TGrafoNoDirigido gd = (TGrafoNoDirigido) UtilGrafos.cargarGrafo("verticesBEA.txt",
                "aristasBEA.txt",
                false, TGrafoNoDirigido.class);

        System.out.println("Llamamos el método sin parámetros:");
        Collection<TVertice> visitadosBEA = gd.bea();
        for (TVertice vert : visitadosBEA) {
            System.out.println(vert.getEtiqueta());
        }

        System.out.println("\nLlamamos el método desde el vértice \"a\":");
        gd.desvisitarVertices();
        visitadosBEA.clear();
        visitadosBEA = gd.bea("a");
        for (TVertice vert : visitadosBEA) {
            System.out.println(vert.getEtiqueta());
        }
    }
}
