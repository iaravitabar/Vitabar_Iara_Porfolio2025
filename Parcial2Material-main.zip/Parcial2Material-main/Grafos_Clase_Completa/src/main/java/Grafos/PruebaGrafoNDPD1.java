package Grafos;

import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;

public class PruebaGrafoNDPD1 {

    // No funca, los archivos son parte del UT7 TA3
    public static void main(String[] args) {

        //Ejercicio 2
        /*TGrafoNoDirigido gd = (TGrafoNoDirigido) UtilGrafos.cargarGrafo("verticesBEA.txt", "aristasBEA.txt",
                false, TGrafoNoDirigido.class);



        List<TArista> lista = new ArrayList<>();
        TGrafoNoDirigido gnd = gd.Prim(lista);
        System.out.println(gnd.getLasAristas()); //Puse un breakpoint y verifique el resultado
        */
        //Ejercicio 3
        /* 
        TGrafoNoDirigido gd = (TGrafoNoDirigido) UtilGrafos.cargarGrafo("PD1Ej3Vertices.txt", "PD1Ej3Aristas.txt",
                false, TGrafoNoDirigido.class);

        LinkedList<TVertice> beaResultado = (LinkedList<TVertice>) gd.bea("a"); //COnvierto bea en una linkedlist, debido a que me importa el orden y en el hashset no lo hay.
        System.out.println(beaResultado); 

         
        TVertice a = gd.buscarVertice("a");
        TVertice g = gd.buscarVertice("g");
        //System.out.println(gd.conectados(a, g));

        //System.out.println(gd.esConexo());

        List<TArista> a_arbol = new ArrayList<>(); 
        List<TArista> a_retroceso = new ArrayList<>();
        gd.clasificarArcosND("a", a_arbol, a_retroceso);
        System.out.println("breakpoint");
        */
        TGrafoNoDirigido gd = (TGrafoNoDirigido) UtilGrafos.cargarGrafo("ArticulacionV.txt", "ArticulacionA.txt",
                false, TGrafoNoDirigido.class);
        LinkedList a = new LinkedList<>();
        int[] contador = new int[1];
        gd.puntosDeArticulacion(a , contador, "N");
        System.out.println("Breakpoint");
    }   
} 
