package Grafos;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Stack;

public class TGrafoNoDirigido extends TGrafoDirigido implements IGrafoNoDirigido {
    protected TAristas lasAristas = new TAristas();

    /**
     *
     * @param vertices
     * @param aristas
     */
    public TGrafoNoDirigido(Collection<TVertice> vertices, Collection<TArista> aristas) {
        super(vertices, aristas);
        lasAristas.insertarAmbosSentidos(aristas);

    }

    @Override
    public boolean insertarArista(TArista arista) {
        boolean tempbool = false;
        TArista arInv = new TArista(arista.getEtiquetaDestino(), arista.getEtiquetaOrigen(), arista.getCosto());
        tempbool = (super.insertarArista(arista) && super.insertarArista(arInv));
        return tempbool;
    }

    public TAristas getLasAristas() {
        return lasAristas;
    }

   @Override
    public TGrafoNoDirigido Prim(Collection par) {
        Set<Comparable> U = new HashSet<>();
        List<Comparable> VCopia = new ArrayList<>(getVertices().keySet());

        par.clear();      //Buscamos pasarlo por parametro por si nos interesa seguir trabajando con dicha coleccion. No es necesario retornarla en java.
        U.add(VCopia.remove(0));
        TArista aristaElegida = null;

        while(VCopia.size() != 0){
            aristaElegida = this.getLasAristas().buscarMin(U, VCopia);
            par.add(aristaElegida);
            VCopia.remove(aristaElegida.getEtiquetaDestino());
            U.add(aristaElegida.getEtiquetaDestino());
        }

        return new TGrafoNoDirigido(this.getVertices().values(), par); //Como U termina siedno igual que V, es lo mismo
        
    }

    //5
    @Override
    public TGrafoNoDirigido Kruskal() {
               LinkedList<TArista> aristasKruskal = new LinkedList(); //Aqui se almacenaran las aristas seleccionadas.
        Map<Comparable, TVertice> vertices = getVertices();

        if (!vertices.isEmpty()) {
            desvisitarVertices();
            HashMap<Comparable, LinkedList<TVertice>> colecciones = new HashMap(vertices.size());
            LinkedList<TVertice> colTemp;

            //Creamos una "coleccion" para cada arista
            for (TVertice v : vertices.values()) {
                colTemp = new LinkedList();
                colTemp.add(v);
                colecciones.put(v.getEtiqueta(), colTemp);
            }

            //Ordenamos todas las aristas del grafo de menor costo a mayor
            LinkedList<TArista> aristasOrdenadas = new LinkedList();
            forAristas:
            for (TArista a : lasAristas) {
                if (aristasOrdenadas.isEmpty() || aristasOrdenadas.getFirst().getCosto() > a.getCosto()) {
                    aristasOrdenadas.addFirst(a);
                    continue;
                }
                for (int i = 1; i < aristasOrdenadas.size(); i++) {
                    if (aristasOrdenadas.get(i).getCosto() > a.getCosto()) {
                        aristasOrdenadas.add(i - 1, a);
                        continue forAristas;
                    }
                }
                aristasOrdenadas.add(a);
            }

            //Conectamos las colecciones de vertices (no conectados) mediante la arista de menor costo posible
            TArista menorArista;
            LinkedList<TVertice> colOrigen, colDestino;
            while (!aristasOrdenadas.isEmpty()) {
                menorArista = aristasOrdenadas.pollFirst();
                colOrigen = colecciones.get(menorArista.etiquetaOrigen);
                colDestino = colecciones.get(menorArista.etiquetaDestino);
                if (colOrigen != colDestino) {
                    colOrigen.addAll(colDestino);
                    for (TVertice v : colDestino) {
                        if (colecciones.get(v.getEtiqueta()) != colOrigen) {
                            colecciones.replace(v.getEtiqueta(), colOrigen);
                        }
                    }
                    aristasKruskal.add(menorArista);
                }
            }
        }

        TGrafoNoDirigido grafo = new TGrafoNoDirigido(vertices.values(), aristasKruskal);
        return grafo;
    }
/*
 * Bea sin comparable. Le pasa por parametro los visitados
 */
    @Override
    public Collection<TVertice> bea() {
        desvisitarVertices();
        LinkedList<TVertice> visitados = new LinkedList<>();
        getVertices().values().forEach(v -> {
            if (!v.getVisitado()) {
                v.bea(visitados);
            }
        });

        return visitados;
    }

    /*
     * bea con etiqueta de origen. no pasa nada por parametro
     */
    @Override
    public Collection<TVertice> bea(Comparable etiquetaOrigen) {
        desvisitarVertices();
        TVertice vertice = this.buscarVertice(etiquetaOrigen);
        if(vertice == null)
            return null;
        return vertice.bea();
    }

    @Override
    public boolean esConexo() {
        LinkedList<Comparable> claves = new LinkedList<>(getVertices().keySet());

        TVertice random = getVertices().get(claves.get(0));

        desvisitarVertices();
        return random.bea().size() == getVertices().size();
    }

    /*
     * LLama al método de el vertice. Primero desvicita y checkea null
     */
    @Override
    public boolean conectados(TVertice origen, TVertice destino) {
        desvisitarVertices();
        if(origen != null && destino != null){
            return origen.conectadoCon(destino);
        }
        return false;
    }

    @Override
    public boolean tieneCiclo() {
        desvisitarVertices();
        Stack<TVertice> pila = new Stack<>();

        for (TVertice vertice : getVertices().values()) {
            if (vertice.getVisitado())
                continue;

            boolean ciclo = vertice.tieneCiclo_TGrafoNoDirigido(pila, null);
            if (ciclo == true)
                return ciclo;
        }

        return false;
    }

    @Override
    public boolean tieneCiclo(Comparable etiquetaOrigen) {
        if (!existeVertice(etiquetaOrigen))
            return false;

        /* Instanciamos los valores iniciales para poder llamar el método de TVertice */
        TVertice v_origen = buscarVertice(etiquetaOrigen);
        Stack<TVertice> pila = new Stack<>();

        return v_origen.tieneCiclo_TGrafoNoDirigido(pila, null);
    }

    @Override
    public boolean tieneCiclo(TVertice vertice) {
        if (!getVertices().containsValue(vertice))
            return false;

        /* Instanciamos los valores iniciales para poder llamar el método de TVertice */
        Stack<TVertice> pila = new Stack<>();

        return vertice.tieneCiclo_TGrafoNoDirigido(pila, null);
    }

    //2
    @SuppressWarnings("unchecked")
    public void clasificarArcosND(Comparable etiquetaOrigen, List<TArista> a_arbol, List<TArista> a_retroceso) {
        desvisitarVertices();
        TVertice v_origen = buscarVertice(etiquetaOrigen);
        if (v_origen == null)
            return;

        v_origen.clasificarArcos_GrafoNoDirigido(a_arbol, a_retroceso, v_origen);
    }

    //3
    @Override
    public List<TVertice> ordenacionTopologica() {
        if (tieneCiclo())
            return null;

        desvisitarVertices();

        List<TVertice> ord = new LinkedList<>();
        for (TVertice vertice : getVertices().values()) {
            if (!vertice.getVisitado())
                vertice.ordenacionTopologica(ord);
        }

        return ord;
    }

    //4
    @SuppressWarnings("unchecked")
    public LinkedList<TVertice> puntosDeArticulacion(LinkedList<TVertice> articulacion, int[] contador, Comparable clave){

        if(this.getVertices().size() > 0){
            return this.getVertices().get(clave).puntosDeArticulacionGND(articulacion, contador, this.getVertices().get(clave));
        }
        return null;
    }
}
