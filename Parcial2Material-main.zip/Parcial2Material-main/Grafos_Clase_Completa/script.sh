#!/bin/bash

# script para renombrar el proyecto
var="package GrafoDirigido;"
bar="package Grafos;"

for file in ./src/main/java/GrafoDirigido/*; do
    sed -i "1s/.*/$bar/" $file
done
