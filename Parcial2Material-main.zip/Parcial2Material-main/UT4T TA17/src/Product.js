import React from "react";
import { useParams, Link } from "react-router-dom";

const products = {
  1: {
    name: "Producto A",
    description: "Descripción del Producto A",
    price: "$100",
  },
  2: {
    name: "Producto B",
    description: "Descripción del Producto B",
    price: "$200",
  },
  3: {
    name: "Producto C",
    description: "Descripción del Producto C",
    price: "$300",
  },
};

export default function Product() {
  const { id } = useParams();
  const product = products[id];

  if (!product) {
    return <h2>Producto no encontrado</h2>;
  }

  return (
    <div>
      <h1>{product.name}</h1>
      <p>{product.description}</p>
      <p>Precio: {product.price}</p>
      <Link to="/">Volver al home</Link>
    </div>
  );
}
