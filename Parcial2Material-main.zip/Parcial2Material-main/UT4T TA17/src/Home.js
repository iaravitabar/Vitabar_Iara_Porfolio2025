import React from "react";
import { Link } from "react-router-dom";

export default function Home() {
  return (
    <div className="container">
      <h1>Bienvenido a la tienda</h1>
      <p>Selecciona un producto:</p>
      <Link to="/product/1">Producto A</Link>

      <Link to="/product/2">Producto B</Link>

      <Link to="/product/3">Producto C</Link>
    </div>
  );
}
