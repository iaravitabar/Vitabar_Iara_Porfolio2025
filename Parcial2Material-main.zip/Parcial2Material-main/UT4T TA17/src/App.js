import "./styles.css";
import React from "react";
import { BrowserRouter, Route, Routes, Link } from "react-router-dom";
import Product from "./Product";
import Home from "./Home";

const Error = () => {
  return <p>Ha ocurrido un error</p>;
};

export default function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/product/:id" element={<Product />} />
        <Route element={<Error />} path="*" />
      </Routes>
    </BrowserRouter>
  );
}
