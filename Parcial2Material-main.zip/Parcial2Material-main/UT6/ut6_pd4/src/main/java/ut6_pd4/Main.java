package ut6_pd4;

import java.util.HashMap;
import java.util.Map;

public class Main {
    public static void main(String[] args) {
        Map<String, Integer> palabras = new HashMap<>();
        String[] palabras2 = ManejadorArchivosGenerico.leerArchivo("libro.txt");
        int contador = 0;
        for(String linea : palabras2){
            String[] lineaSplit = linea.split(" ");
            for(String palabraSpliteada : lineaSplit){
                contador = 0;
                if (palabraSpliteada.endsWith(",") || palabraSpliteada.endsWith(".") || palabraSpliteada.endsWith("?")) {
                    palabraSpliteada = palabraSpliteada.substring(0, palabraSpliteada.length() - 1);
                } else if (palabraSpliteada.startsWith("¿")) {
                    palabraSpliteada = palabraSpliteada.substring(1);
                }
                if(palabras.containsKey(palabraSpliteada)){
                    contador = palabras.get(palabraSpliteada);
                }
                palabras.put(palabraSpliteada, ++contador);
            }
        }
        System.out.println(palabras);
    }
}
