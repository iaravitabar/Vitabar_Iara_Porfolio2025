package ut6_pd5;

public class Main {
    public static void main(String[] args) {
        TArbolTrieHashMap trie = new TArbolTrieHashMap();
        trie.insertar("casa");
        trie.insertar("casamiento");
        trie.insertar("ca2samiento");
        trie.insertar("casamient2o");
        trie.insertar("ca22samiento");
        trie.insertar("arbol");
        trie.insertar("gritos");
        System.out.println(trie.buscar("casa"));
        System.out.println(trie.predecir("g"));
    }
}