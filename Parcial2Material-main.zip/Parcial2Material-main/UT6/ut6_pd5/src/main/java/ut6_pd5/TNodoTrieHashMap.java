package ut6_pd5;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;

public class TNodoTrieHashMap implements INodoTrie {

    private HashMap<Character, TNodoTrieHashMap> hijos;

    private boolean esPalabra;

    public TNodoTrieHashMap(){
        hijos = new HashMap<>();
        esPalabra = false;
    }

    public boolean esPalabra(){
        return this.esPalabra;
    }

    public void setPalabra(){
        this.esPalabra = true;
    }

    @Override
    public int buscar(String s) {
        TNodoTrieHashMap nodo = this;
        for (int c = 0; c < s.length(); c++) {
            char letra = s.charAt(c);
            if(nodo.hijos.get(letra) == null){
                return 0;
            }
            nodo = nodo.hijos.get(letra);
        }
        if(nodo.esPalabra)
        return 1;
        return 0;
    }

    @Override
    public void predecir(String prefijo, List<String> palabras) {
        TNodoTrieHashMap nodo = buscarNodoTrie(prefijo);
        if(nodo != null){
            predecir(prefijo, (LinkedList<String>) palabras, nodo);
        }
    }
    private void predecir(String s, LinkedList<String> palabras, TNodoTrieHashMap nodo) { 
        if (nodo.esPalabra) {
            palabras.add(s);
        }
        for(char letra : nodo.hijos.keySet()){
            predecir(s + letra, palabras, nodo.hijos.get(letra));
        }
    }

    private TNodoTrieHashMap buscarNodoTrie(String s) {
        TNodoTrieHashMap nodo = this;
        for(int c = 0; c < s.length(); c++){
            char letra = s.charAt(c);
            if(nodo.hijos.get(letra) == null){
                return null;
            }
            nodo = nodo.hijos.get(letra);
        }
        return nodo;
    }
    @Override
    public void insertar(String unaPalabra) {
        TNodoTrieHashMap nodo = this;
        for (int c = 0; c < unaPalabra.length(); c++) {
            char letra = unaPalabra.charAt(c);
            if(nodo.hijos.get(letra) == null){
                nodo.hijos.put(letra, new TNodoTrieHashMap());
            }
            nodo = nodo.hijos.get(letra);
        }
        nodo.setPalabra();
    }

    @Override
    public void imprimir() {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'imprimir'");
    }
    
}
