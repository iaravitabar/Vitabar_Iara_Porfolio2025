import "./styles.css";
import { BrowserRouter, Routes, Route, Link } from "react-router-dom";

function Home() {
  return (
    <div className="div">
      <h1>Estas en el home</h1>
      <Link to={"/About"}>Ir a mi about</Link>
      <Link to={"/Config"}>Ir a mi config</Link>
    </div>
  );
}

function About() {
  return (
    <div className="div">
      <h1>Estas en el About</h1>
      <Link to={"/Home"}>Ir al home</Link>
      <Link to={"/Config"}>Ir a mi config</Link>
    </div>
  );
}
function Config() {
  return (
    <div className="div">
      <h1>Estas en el Config</h1>
      <Link to={"/Home"}>Ir a mi home</Link>
      <Link to={"/About"}>Ir a mi about</Link>
    </div>
  );
}
function Error() {
  return <p>Ha ocurrido un error</p>;
}

export default function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route element={<Home />} path="/Home" exact />
        <Route element={<About />} path="/About" exact />
        <Route element={<Config />} path="/Config" exact />
        <Route element={<Home />} path="/" exact />
        <Route element={<Error />} path="*" />
      </Routes>
    </BrowserRouter>
  );
}
