import "./styles.css";
import { createContext, useContext, useState } from "react";

const UserContext = createContext();

function Mostrador() {
  const userName = useContext(UserContext);
  return <p>Nombre: {userName}</p>;
}

function Inp({ setUserName }) {
  const cambioNombre = (event) => {
    setUserName(event.target.value);
  };

  return (
    <div>
      <input
        type="text"
        placeholder="Cambie el nombre"
        onChange={cambioNombre}
      />
      <Mostrador />
    </div>
  );
}

export default function Nombre() {
  const [userName, setUserName] = useState("");

  return (
    <UserContext.Provider value={userName}>
      <Inp setUserName={setUserName} />
    </UserContext.Provider>
  );
}
