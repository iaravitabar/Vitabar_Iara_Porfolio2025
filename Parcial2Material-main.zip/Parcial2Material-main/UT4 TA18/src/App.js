import "./styles.css";
import React, { useState } from "react";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import Home from "./Home";
import Protected from "./Protected";
import Secretos from "./Secretos";
import Publico from "./Publico";

const Error = () => {
  return <p>Ha ocurrido un error</p>;
};

export default function App() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);

  const login = () => {
    setIsAuthenticated(true);
    
  };

  const logout = () => {
    setIsAuthenticated(false);
  };

  return (
    <BrowserRouter>
      <div>
        <button onClick={login}>Iniciar Sesión</button>
        <button onClick={logout}>Cerrar Sesión</button>

        <Routes>
          <Route path="/" element={<Home />} />

          <Route element={<Protected isAuthenticated={isAuthenticated} />}>
            <Route element={<Secretos />} path="/secretos" exact />
          </Route>
          <Route path="/publico" element={<Publico />} />
          <Route element={<Error />} path="*" />
        </Routes>
      </div>
    </BrowserRouter>
  );
}
