import React from "react";
import { Link } from "react-router-dom";

export default function Publico() {
  return (
    <div>
      <h1>Publico</h1>
      <p>Pegi 0</p>
      <Link to="/">Volver al home</Link>
    </div>
  );
}
