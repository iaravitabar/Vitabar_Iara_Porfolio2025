import React from "react";
import { Link } from "react-router-dom";

export default function Secretos() {
  return (
    <div>
      <h1>Secretos</h1>
      <p>Solo accesible para usuarios autenticados.</p>
      <Link to="/">Volver al home</Link>
    </div>
  );
}
