package com.example;

public class Main {
    public static void main(String[] args) {
        
    ManejadorArchivosGenerico manejador = new ManejadorArchivosGenerico();
    String[] lineas = manejador.leerArchivo("numeros\numeros.txt");
    
    
    Algoritmo algoritmo = new Algoritmo();
    int counter = algoritmo.sortWithCounter(lineas);

    System.out.println("Largo N: " + lineas.length);
    System.out.println("Contador de comparaciones: " + counter);
    System.out.println("Primer número del arreglo: " + lineas[0]);
    System.out.println("Último número del arreglo: " + lineas[lineas.length - 1]);
    }
    
}

