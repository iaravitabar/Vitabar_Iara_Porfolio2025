package com.example;

public class Algoritmo {
    
    public int sortWithCounter(int[] lineas) {
        int counter = 0;
        int n = lineas.length;
        for (int i = 0; i < n - 1; i++) {
            for (int j = n - 1; j > i; j--) {
                counter++; // Contador para contar las comparaciones
                if (lineas[j] < lineas[j - 1]) {
                    swap(lineas, j, j - 1);
                }
            }
        }
        return counter;
    }

    private void swap(int[] array, int i, int j) {
        int temp = array[i];
        array[i] = array[j];
        array[j] = temp;
    }

    
    public int sortWithCounter(String[] lineas) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'sortWithCounter'");
    }
}
