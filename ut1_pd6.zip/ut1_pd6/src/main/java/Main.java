

/*
 * UNIDAD	TEMÁTICA	1:	Introducción	a	JAVA	
    PRACTICOS	DOMICILIARIOS	INDIVIDUALES	#6
    EJERCICIO	#1	Bucles	anidados
    Escribe un programa llamado Tablero que imprima un tablero de nxn siguiendo el siguiente
    patrón de ejemplo (7x7):
    # # # # # # #
    # # # # # # #
    # # # # # # #
    # # # # # # #
    # # # # # # #
    # # # # # # #
    # # # # # # #
    Creando un método estático llamado “imprimirTablero” en el archivo “Principal” del
    programa. La firma de este método será:
    public static void imprimirTablero(int largo, int ancho);
*/

public class Main {
    public static void main(String[] args) {
        imprimirTablero(7, 7);
    }
    public static void imprimirTablero(int largo, int ancho){
        for (int i =0; i < largo; i++){
            for (int j = 0; j< ancho; j++){
                System.out.print("#");
            }
            System.out.println();
        }
        if (largo<= 0 || ancho <= 0){
            System.out.println("ingrese valores validos");
            return;
        }
    }
}