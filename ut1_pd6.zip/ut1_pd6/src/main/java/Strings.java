public class Strings {
    
}
/*
 * Ejercicio	#3	-	Entrada	de	Datos	y	manejo	de	String
    Parte a)
    El teclado T9 de los celulares mapea los dígitos a letras. Generalmente se encuentran
    agrupados de la siguiente forma: ABC(2), DEF(3), GHI(4), JKL(5), MNO(6), PQRS(7), TUV(8),
    WXYZ(9), !espacio”(0), !.”(1).
    Escribe un programa Java que lea un archivo !entrada.txt” y escriba en un archivo !salida.txt”
    los dígitos correspondientes al texto. Puedes asumir que el texto de entrada no tiene ningún
    otro caracter más que los nombrados anteriormente. Considera letras mayúsculas y
    minúsculas.
    Los archivos deben estar en la carpeta src del proyecto.
    Creando un método estático llamado “transformarTextoT9” en la clase “Principal” del
    programa. La firma de este método será:
    public static void transformarTextoT9(String rutaArchivo);
    Parte b)
    Escribe un programa Java que lea de un archivo !entrada.txt”, invierta la entrada, pase a dígitos
    el texto invertido y escriba la salida en !salida.txt”.
    Creando un método estático llamado “transformarT9Texto” en la clase “Principal” del
    programa. La firma de este método será:
    public static void transformarT9Texto(String rutaArchivo); 
 */
