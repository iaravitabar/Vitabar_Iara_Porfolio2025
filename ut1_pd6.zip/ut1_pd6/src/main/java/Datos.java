import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;


public class Datos {
    public static void main (String[] args){
        String nombreArchivo = "entrada.txt";
        String rutaArchivo = nombreArchivo;
        try {
            FileWriter fileWriter = new FileWriter(rutaArchivo);
            BufferedWriter bufferedWriter = new BufferedWriter(fileWriter);
            bufferedWriter.write("12\n");
            bufferedWriter.write("33.44\n");
            bufferedWriter.write("Peter");
            bufferedWriter.close();

            System.out.println("El archivo '" + nombreArchivo + "' ha sido creado en el directorio actual.");
        } catch (IOException e) {
            System.err.println("Error al crear el archivo: " + e.getMessage());
        }
        leerEntradaArchivo("entrada.txt");

        //parte b
        leerEntradaStdin();
    }

    public static void leerEntradaArchivo(String rutaArchivo){
        try( BufferedReader br = new BufferedReader(new FileReader(rutaArchivo))){
            String ent = br.readLine();
            String flo = br.readLine();
            String str = br.readLine();

            int entero = Integer.parseInt(ent);
            double flotante = Double.parseDouble(flo);
            
            System.out.println("El entero leído es: " + entero);
            System.out.println("El número de punto flotante es: " + flotante);
            System.out.println("La cadena leída es \"" + str + "\"");
            System.out.println("¡Hola " + str + "! La suma de " + entero + " y " + flotante + " es " + (entero + flotante) + ".");
            System.out.println("La división entera de " + flotante + " y " + entero + " es " + ((int) (flotante / entero)) + " y su resto es " + (flotante % entero) + ".");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    //parte b
    public static void leerEntradaStdin(){
        Scanner scanner = new Scanner (System.in);
        System.out.print("Ingrese el radio: ");
        double r = scanner.nextDouble();
        scanner.close();
        double area = Math.PI*r*r;
        double perímetro = 2 * Math.PI *r;
        System.out.println("El area es:"+ area);
        System.out.println("el perimetro es: "+ perímetro);
    }
}