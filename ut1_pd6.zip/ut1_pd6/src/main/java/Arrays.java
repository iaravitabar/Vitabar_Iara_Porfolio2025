
/*
 * Ejercicio	#4	-	Arrays
    Escribe un programa Java capaz de realizar la multiplicación de vectores de tipo int. Sólamente
    debe devolver el resultado si los vectores se pueden multiplicar.
    En lenguaje natural, describe previamente la operación y las condiciones que deben cumplirse
    para que sea posible realizarla. 
    
        -Para que sea posible la operacion y multiplicar los vectores de tipo int, es necesario que ambos
        vectores no sean nulos, que esten definidos correctamente con el mismo tipo de dato y que tengan 
        la misma longitud.
        MIN_VALUE: constante que contiene el valor minimo un int puede tener
                lo comparo con MIN_VALUE porque me asegura que no es valido. (para eso uso Integer)
 */
public class Arrays{
    public static void main(String[] args) {
        int [] a = {1, 2};
        int [] b = {1,2};
        int resultado = mult(a,b);
        if (resultado != Integer.MIN_VALUE) {
            System.out.println("El resultado es: " + resultado);
        } else {
            System.out.println("No es posible multiplicar los vectores");
        }
    }
    public static int mult(int[] a, int[] b){
        if (a == null || b == null || a.length != b.length) {
            return Integer.MIN_VALUE;
        }
        int resultado = 0;
        for (int i = 0; i < a.length; i++) {
            resultado += a[i] * b[i];
        }
        return resultado;
    }

}