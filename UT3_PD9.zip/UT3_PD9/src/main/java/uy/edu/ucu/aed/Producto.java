package uy.edu.ucu.aed;

public class Producto implements IProducto{

    public Comparable codProducto;
    public String nombre;
    public Integer precio;
    public Integer stock;

    public Producto(Comparable CodProducto, String Nombre, Integer Precio, Integer Stock) {
        this.codProducto = CodProducto;
        this.nombre = Nombre;
        this.precio = Precio;
        this.stock = Stock;
    }
     /**
     * Retorna el codigo del Producto.
     *
     * @return codigo del Producto.
     */
    public Comparable getCodProducto();

    /**
     * Retorna el precio unitario del Producto.
     *
     * @return precio del Producto.
     */
    public Integer getPrecio();

    public void setPrecio(Integer precio);

    /**
     * Retorna el stock del Producto.
     *
     * @return stock del Producto.
     */
    public Integer getStock();

    public void agregarCantidadStock(Integer stock);

    public void restarCantidadStock(Integer stock);

    /**
     * Retorna la descripcion/nombre del Producto.
     *
     * @return descripci�n del Producto.
     */
    public String getNombre();

    public void setNombre(String nombre);

}
