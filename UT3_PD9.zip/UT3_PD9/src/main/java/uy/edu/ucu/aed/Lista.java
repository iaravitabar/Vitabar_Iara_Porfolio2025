package uy.edu.ucu.aed;

public class Lista<T> implements ILista<T> {

    private Nodo<T> primero;

    public Lista() {
        primero = null;
    }

    @Override
    public void insertar(T dato, Comparable clave) {
        // TODO Auto-generated method stub
        // throw new UnsupportedOperationException("Unimplemented method 'insertar'");
        Nodo nodoDato = new Nodo(clave, dato);
        Nodo elemento = this.primero;
        boolean bandera = false;

        if (this.primero == null) {
            this.primero = nodoDato;
        } else {
            while (elemento.getSiguiente() != null) {
                elemento = elemento.getSiguiente();
            }
            elemento.setSiguiente(nodoDato);
        }
    }

    @Override
    public T buscar(Comparable clave) {
        // TODO Auto-generated method stub
        // throw new UnsupportedOperationException("Unimplemented method 'buscar'");
        Nodo elemento = this.primero;
        while (elemento.getSiguiente() != null) {
            if (elemento.getEtiqueta() == clave) {
                return (T) elemento;
            }
        }
        return null;
    }

    @Override
    public boolean eliminar(Comparable clave) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'eliminar'");
    }

    @Override
    public String imprimir() {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'imprimir'");
    }

    @Override
    public String imprimir(String separador) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'imprimir'");
    }

    @Override
    public int cantElementos() {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'cantElementos'");
    }

    @Override
    public boolean esVacia() {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'esVacia'");
    }

    @Override
    public void setPrimero(Nodo<T> unNodo) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'setPrimero'");
    }


    // implementar los metodos indicados en la interfaz
}
