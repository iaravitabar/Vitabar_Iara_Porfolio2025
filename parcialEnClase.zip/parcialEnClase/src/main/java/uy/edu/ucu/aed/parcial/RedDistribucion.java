package uy.edu.ucu.aed.parcial;

import uy.edu.ucu.aed.tda.*;

import java.util.*;

public class RedDistribucion extends TGrafoNoDirigido {

    public RedDistribucion() {
        super(new ArrayList<>(), new ArrayList<>());
    }

    public class  resultado{
        int costo;
        List<Ruta> lista;
        TCaminos caminos;//son los vertices conectados por adyacencias

        public resultado(int c, List<Ruta> ruta,TCaminos camino){
            costo=c;
            lista=ruta;
            caminos=camino;
        }

    }
    public resultado construirRedMinimaConPrioridad() {
        Rutas T =new Rutas();

        Rutas aristasOrdenadas= this.getLasAristas();
        Collections.sort(aristasOrdenadas);
        Map<Comparable,Ciudad> ciudades = this.getVertices();
        int costoTotal =0;
        TCaminos caminos=new TCaminos();



        for(Ruta r: aristasOrdenadas){
            if (r.getEsPrioritaria()){
                Ciudad origen = ciudades.get(r.getEtiquetaOrigen());
                Ciudad destino= ciudades.get(r.getEtiquetaDestino());

                if (!conectados(origen,destino)){
                    T.add(r);
                    caminos.conectar(origen.getEtiqueta(),destino.getEtiqueta());
                    costoTotal+=r.getCosto();
                    aristasOrdenadas.remove(r);
                }
            }
        }
        int i=0;
        if(T.size()<ciudades.size()-1)
            for(Ruta r: aristasOrdenadas){
                Ciudad origen = ciudades.get(r.getEtiquetaOrigen());
                Ciudad destino= ciudades.get(r.getEtiquetaDestino());
                if (!conectados(origen,destino)){
                    T.add(r);
                    caminos.conectar(origen.getEtiqueta(),destino.getEtiqueta());
                    costoTotal+=r.getCosto();
                }
                i++;
        }
        return new resultado(costoTotal,T,caminos);
    }
}

