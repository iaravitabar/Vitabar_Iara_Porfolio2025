package uy.edu.ucu.aed;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import uy.edu.ucu.aed.parcial.RedDistribucion;
import uy.edu.ucu.aed.tda.Ciudad;
import uy.edu.ucu.aed.tda.Ruta;

import java.util.List;

/**
 * Unit test for implemented methods.
 */
public class Test_Junit4 {
    RedDistribucion red;

    @BeforeEach
    public void setUp() {

        RedDistribucion red = new RedDistribucion();
        Ciudad mvd = new Ciudad("Montevideo");
        Ciudad c1 = new Ciudad("Canelones");
        Ciudad c2 = new Ciudad("Florida");
        Ciudad c3 = new Ciudad("Rivera");

        red.insertarVertice(mvd);
        red.insertarVertice(c1);
        red.insertarVertice(c2);
        red.insertarVertice(c3);

        red.insertarArista(new Ruta("Montevideo", "Canelones", 5, true));
        red.insertarArista(new Ruta("Montevideo", "Florida", 10, false));
        red.insertarArista(new Ruta("Canelones", "Rivera", 3, false));
        red.insertarArista(new Ruta("Florida", "Rivera", 2, true));
    }


    @Test
    public void arbolDeCostoMinimo() {
        List<Ruta> ruta = red.construirRedMinimaConPrioridad();

        // Ejemplo de resultado esperado, suponiendo que retorna un MST con esas rutas
        List<String> esperado = new ArrayList<>();
        esperado.add("Florida - Rivera"); // 2
        esperado.add("Canelones - Rivera"); // 3
        esperado.add("Montevideo - Canelones"); // 5

        // Convertimos ruta real a string para comparar
        List<String> actual = new ArrayList<>();
        for (Ruta r : ruta) {
            actual.add(r.getOrigen() + " - " + r.getDestino());
        }

        assertEquals(esperado, actual);
    }
    @Test
    public void costoEsperado(){
        List<Ruta> ruta = red.construirRedMinimaConPrioridad();

    }

    @AfterEach
    public void tearDown() {
        // Release any resources or clean up after the tests
        red= null;
    }

    /**
     * Sample test in JUnit 4
     */
    @Test
    public void shouldAnswerWithTrueInJUnit4Test() {
        assertTrue(instanceVariable != null);
    }
}
