package com.example;

/*
 * UNIDAD TEMÁTICA 1: Introducción a JAVA
    PRACTICOS DOMICILIARIOS INDIVIDUALES #8
    EJERCICIO #1
    Referencia: ORACLE JAVA TUTORIAL.
    Un marcapasos debe funcionar consumiendo la menor cantidad de energía posible y ser lo
    más barato posible, por lo que incluye una mínima cantidad de memoria.
    Con sus sensores obtiene continuamente las siguientes medidas, con los rangos que se
    indican:
    • Presión Sanguínea (0-250)
    • Frecuencia cardíaca (0-226)
    • Nivel de azúcar en sangre. (0 - 1000).
    Además, para autodiagnóstico mantiene un registro de:
    • Máxima fuerza a la que fue expuesto (0-3.000.000.000).
    • Mínimo tiempo entre latidos (0-100 con decimales).
    • Batería restante. (% de batería restante con decimales con la mayor precisión
    posible).
    • Código del Fabricante (Números y letras, máximo 8 caracteres).
    Trabajo a realizar:
    a) Crear una clase "Marcapasos" que contenga variables para almacenar esta
    información. Utilice los tipos de datos primitivos de java teniendo en cuenta que se
    quiere consumir la menor cantidad de memoria posible.

        para eso: tipo de datos primitivos = mas eficiencia, menos mem.
        RANGOS:
        short: 2 bytes
        byte: 1 byte
        int: 4 bytes
        float: 4 bytes
        double: 8 bytes
    b) Calcular cuánta memoria consume un objeto de su clase (considerando solamente el
    espacio ocupado por las variables indicadas).
    c) Remit el Código JAVA y el resultado de todos los cálculos en un archivo “PD8.zip” a la
    tarea correspondiente de Ejercicios Domiciliarios.
    */

    /*
     * para eso: tipo de datos primitivos = mas eficiencia, menos mem.
     * int o double ocupan mas, short, byte tipos mas chicos = menos mem
        RANGOS:
        short: 2 bytes
        byte: 1 byte
        int: 4 bytes
        float: 4 bytes
        double: 8 bytes

        para calcular cuanta mem:
        pasar cuanto ocupan a byte y sumarlos todos
        para el string como tiene que ser de 8 caracteres son 2 bytes
        
        .BYTES = METODO ESTATICO DE LAS CLASES DE LOS TIPOS PRIMITIVOS OBTIENE CANT BYTES DEL TIPO
     */
public class Marcapasos {
    private byte presionSanguinea;
    private short frecuenciaCardica;
    private short nivelAzucar;
    private int maxFuerza;
    private float minTiempo;
    private double batRestante;
    private String codigoFabricante;

    public Marcapasos(byte presionSanguinea, short frecuenciaCardica, short nivelAzucar, int maxFuerza, float minTiempo, double batRestante, String codigoFabricante){
        this.presionSanguinea = presionSanguinea;
        this.frecuenciaCardica = frecuenciaCardica;
        this.nivelAzucar = nivelAzucar;
        this.maxFuerza = maxFuerza;
        this.minTiempo = minTiempo;
        this.batRestante = batRestante;
        this.codigoFabricante = codigoFabricante;
        }

    public long memoriaConsumida() {
        long  mem= 0;
        mem += Byte.BYTES;
        mem += Short.BYTES;
        mem += Short.BYTES;
        mem += Integer.BYTES;
        mem += Float.BYTES;
        mem += Double.BYTES;
        mem += codigoFabricante.length() * 2;
        return mem;
    }
    public static void main(String[] args) {
        Marcapasos marcapasos = new Marcapasos((byte) 120, (short) 80, (short) 85, 1500000000, 50.0f, 75.0, "IARA248");
        long memoriaConsumida = marcapasos.memoriaConsumida();
        System.out.println("El espacio que ocupa en bytes es: "+ memoriaConsumida);
    }
}

