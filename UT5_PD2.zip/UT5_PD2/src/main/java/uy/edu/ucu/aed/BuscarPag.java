package uy.edu.ucu.aed;

import java.util.List;

public class BuscarPag {
    
    private TArbolTrie trie;
    public BuscarPag(TArbolTrie trie){
        this.trie = trie;
    }

    public List<Integer> buscarPag(String palabra){
        List<Integer> paginas = trie.buscarPaginas(palabra);
        if(paginas!= null){
            System.out.println("La palabra '" + palabra + "' se encuentra en las páginas: " + paginas);
        } else {
            System.out.println("La palabra '" + palabra + "' no está en el libro.");
        }
        return paginas;
    }
}
