package uy.edu.ucu.aed;

public class Main {
    public static void main(String[] args) {
        
        TArbolTrie trie = new TArbolTrie();
        trie.insertar("Ala");
        trie.insertarPaginas("Ala", new int[]{1, 3, 88});

        BuscarPag buscador = new BuscarPag(trie);

        // Ejemplo de búsqueda de páginas para una palabra
        buscador.buscarPag("Programa");
        buscador.buscarPag("Ala");
    }
}

