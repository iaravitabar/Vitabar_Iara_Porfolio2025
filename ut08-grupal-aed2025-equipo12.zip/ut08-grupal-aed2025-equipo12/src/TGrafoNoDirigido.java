import java.util.Collection;
import java.util.LinkedList;
import java.util.*;


public class TGrafoNoDirigido extends TGrafoDirigido implements IGrafoNoDirigido {
    protected TAristas lasAristas = new TAristas();

    /**
     * @param vertices
     * @param aristas
     */
    public TGrafoNoDirigido(Collection<TVertice> vertices, Collection<TArista> aristas) {
        super(vertices, aristas);
        lasAristas.insertarAmbosSentidos(aristas);

    }

    @Override
    public boolean insertarArista(TArista arista) {
        boolean tempbool = false;
        TArista arInv = new TArista(arista.getEtiquetaDestino(), arista.getEtiquetaOrigen(), arista.getCosto());
        tempbool = (super.insertarArista(arista) && super.insertarArista(arInv));
        return tempbool;
    }

    public TAristas getLasAristas() {
        return lasAristas;
    }


    @Override
    public TGrafoNoDirigido Prim() {
        LinkedList<Comparable> u = new LinkedList();
        LinkedList<Comparable> v = new LinkedList<>(getVertices().keySet());
        Comparable tmp = v.getFirst();
        u.add(tmp);
        v.remove(tmp);
        double costoPrim = 0.0;

        TAristas aristasAAM = new TAristas();
        while (!v.isEmpty()){
            TArista tmpArista = lasAristas.buscarMin(u,v);
            aristasAAM.add(tmpArista);
            v.remove(tmpArista.etiquetaDestino);
            u.add(tmpArista.etiquetaDestino);
            costoPrim = costoPrim + tmpArista.costo;
        }
        TGrafoNoDirigido resultado = new TGrafoNoDirigido(getVertices().values(), aristasAAM);
        return resultado;
    }

    @Override
    public TGrafoNoDirigido Kruskal() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public Collection<TVertice> bea(Comparable etiquetaOrigen) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public Collection<TVertice> bea() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public LinkedList<TVertice> puntosDeArticulacion(Comparable etOrigen) {
        desvisitarVertices();

        LinkedList<TVertice> puntosDeArticulacion = new LinkedList<>();
        TVertice vertOrigen = (TVertice) this.getVertices().get(etOrigen);

        if (vertOrigen != null) {
            vertOrigen.puntosDeArticulacion(puntosDeArticulacion, new int[1]);
        }

        return puntosDeArticulacion;
    }
}
