
import static java.lang.System.in;
import java.util.Collection;
import java.util.ArrayList;

public class main {

    public static void main(String[] args) {
        // TGrafoDirigido gd = (TGrafoDirigido) UtilGrafos.cargarGrafo("./src/aeropuertos_1.txt", "./src/conexiones_1.txt",
        //         false, TGrafoDirigido.class);



        // Collection<TVertice> recorrido_Asuncion = gd.bpf("Asuncion");
        // // imprimir etiquetas del bpf desde Asunción....
        // for (TVertice etVert : recorrido_Asuncion) {
        //     System.out.print(etVert + " ");
        // }


        // TCaminos caminos = gd.todosLosCaminos("Santos", "Curitiba");

        // caminos.imprimirCaminosConsola();

        Collection<TVertice> vertices = new ArrayList<>();
        Collection<TArista> aristas = new ArrayList<>();

        TGrafoNoDirigido grafo = new TGrafoNoDirigido(vertices, aristas);

        grafo.insertarVertice("NAIROBI");
        grafo.insertarVertice("CAIRO");
        grafo.insertarVertice("MONROVIA");
        grafo.insertarVertice("GAROUA");
        grafo.insertarVertice("MEKELE");
        grafo.insertarVertice("PRAIA");

        grafo.insertarArista(new TArista("NAIROBI", "CAIRO", 1));
        grafo.insertarArista(new TArista("NAIROBI", "MONROVIA", 1));
        grafo.insertarArista(new TArista("NAIROBI", "GAROUA", 1));
        grafo.insertarArista(new TArista("MONROVIA", "GAROUA", 1));
        grafo.insertarArista(new TArista("MONROVIA", "MEKELE", 1));
        grafo.insertarArista(new TArista("GAROUA", "MEKELE", 1));
        grafo.insertarArista(new TArista("MEKELE", "PRAIA", 1));

        Collection<TVertice> puntosArticulacion = grafo.puntosDeArticulacion("NAIROBI");

        System.out.println("Puntos de articulación:");
        for (TVertice vertice : puntosArticulacion) {
            System.out.println("- " + vertice.getEtiqueta());
        }
    }
}
