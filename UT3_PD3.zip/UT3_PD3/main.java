public class main {
    public static void main (String [] args){
        ILista<String> lista = new Lista <>();

        lista.insertar("I", "Dato I");
        lista.insertar("A","dato A");
        lista.insertar("R","dato R");
        lista.insertar("A","dato A");

        System.out.println(("elementos en la lista:"));
        System.out.println((lista.imprimir("")));

        System.out.println("buscar elemento I:" + lista.buscar("A"));

        lista.eliminar("R");
        System.out.println("Elementos en la lista después de eliminar 'R':");
        System.out.println(lista.imprimir());

        System.out.println("¿La lista está vacía?: " + lista.esVacia());
    }
}
