import java.util.ArrayList;

public class Lista<T> implements ILista<T> {
    private Nodo<T> primero;

    public Lista() {
        primero = null;
    }

    @Override
    public void insertar(Nodo<T> nodo) {
        if (primero == null) {
            primero = nodo;
        } else {
            Nodo<T> temp = primero;
            while (temp.getSiguiente() != null) {
                temp = temp.getSiguiente();
            }
            temp.setSiguiente(nodo);
        }
    }

    @Override
    public void insertar(Comparable etiqueta, T dato) {
        insertar(new Nodo<>(dato, etiqueta));
    }

    @Override
    public Nodo<T> buscar(Comparable clave) {
        Nodo<T> temp = primero;
        while (temp != null) {
            if (temp.getEtiqueta().compareTo(clave) == 0) {
                return temp;
            }
            temp = temp.getSiguiente();
        }
        return null;
    }

    @Override
    public boolean eliminar(Comparable clave) {
        if (primero == null) {
            return false;
        }
        if (primero.getEtiqueta().compareTo(clave) == 0) {
            primero = primero.getSiguiente();
            return true;
        }
        Nodo<T> temp = primero;
        while (temp.getSiguiente() != null) {
            if (temp.getSiguiente().getEtiqueta().compareTo(clave) == 0) {
                temp.setSiguiente(temp.getSiguiente().getSiguiente());
                return true;
            }
            temp = temp.getSiguiente();
        }
        return false;
    }

    @Override
    public String imprimir() {
        StringBuilder sb = new StringBuilder();
        Nodo<T> temp = primero;
        while (temp != null) {
            sb.append(temp.getEtiqueta()).append(" ");
            temp = temp.getSiguiente();
        }
        return sb.toString();
    }

    @Override
    public String imprimir(String separador) {
        StringBuilder sb = new StringBuilder();
        Nodo<T> temp = primero;
        while (temp != null) {
            sb.append(temp.getEtiqueta()).append(separador);
            temp = temp.getSiguiente();
        }
        return sb.toString();
    }

    @Override
    public int cantElementos() {
        int count = 0;
        Nodo<T> temp = primero;
        while (temp != null) {
            count++;
            temp = temp.getSiguiente();
        }
        return count;
    }

    @Override
    public boolean esVacia() {
        return primero == null;
    }

    @Override
    public void setPrimero(Nodo<T> unNodo) {
        this.primero = unNodo;
    }
}
