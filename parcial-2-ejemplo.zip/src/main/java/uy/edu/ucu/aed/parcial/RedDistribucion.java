package uy.edu.ucu.aed.parcial;

import uy.edu.ucu.aed.tda.Ruta;
import uy.edu.ucu.aed.tda.TGrafoNoDirigido;

import java.util.ArrayList;
import java.util.List;

public class RedDistribucion extends TGrafoNoDirigido {

    public RedDistribucion() {
        super(new ArrayList<>(), new ArrayList<>());
    }

    public List<Ruta> construirRedMinimaConPrioridad() {
        throw new UnsupportedOperationException("Falta implementar esta función.");
    }
}

