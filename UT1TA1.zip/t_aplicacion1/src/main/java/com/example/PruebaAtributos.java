package com.example;

public class PruebaAtributos 
{
     // letra y guion bajo
    private double aNumero;
    private String _conGuionBajo;

    // no puede empezar con un numero
    // private int 1noValido; // MAL
    private boolean numero1;

    // no puede tener espacios
    // private int mi variable; // MAL
    private char miVariable;

    // no puede tener caracteres especiales
    // private int mi*variable; // MAL
    private long miVariableSinCaracteresEspeciales;

    // no puede tener guion medio
    // private int mi-variable; // MAL
    private float miVariableSinGuionMedio;

    // las constantes se escriben en mayusculas
    private static final String MI_CONSTANTE = "Constante";

    // las variables se escriben en camelCase
    private int miVariableEnCamelCase;


    void unMetodo()
    {
        int y;
        System.out.println(miVariable); // Funciona porque java inicializa atributos automaticamente. Pero no se recomienda
        //System.out.println(y); ESTO ESTA MAL. Java no permite usar variables locales sin inicializar
    }
}
