package com.example;

class ArithmeticDemo { 

    void Method()
    {
        int result = 1 + 2;  
        System.out.println(result); 
        result--;  
        System.out.println(result); 
        result *= 2; // tambien podria ser  result<<; 
        System.out.println(result); 
        result /= 2;  
        System.out.println(result); 
        result = (result + 8) % 7;  
        System.out.println(result); 
    }

}