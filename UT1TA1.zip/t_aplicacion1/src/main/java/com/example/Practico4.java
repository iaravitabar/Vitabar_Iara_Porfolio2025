package com.example;

class Practico4 {

    void Method() {
        int aNumber = 3;

        if (aNumber >= 0) // Aca no entra si es menor a 0
            if (aNumber == 0)
                System.out.println("first string"); // Solo imprime si es igual a 0
            else
                System.out.println("second string"); // Imprime solo si es mayor a 0

        System.out.println("third string"); // Se imprime siempre

        // Si es menor a 0: solo imprime el tercero
        // Si es igual a 0: imprime el primero y el tercero
        // Si es mayor a 0: imprime el segundo y el tercero
    }

    void MethodRefactored() {
        int aNumber = 3;
        
        if (aNumber >= 0) {
            if (aNumber == 0) {
                System.out.println("first string");
            } else {
                System.out.println("second string");
            }
        }

        System.out.println("third string");
    }
}