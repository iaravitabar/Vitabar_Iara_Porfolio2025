package com.example;

/**
 * Hello world!
 */
public final class App {
    private App() {
    }

    public static void main(String[] args) 
    {
        Practico4 practico4 = new Practico4();
        practico4.Method();
    }
}
