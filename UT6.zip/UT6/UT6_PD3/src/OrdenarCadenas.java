import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Scanner;

public class OrdenarCadenas {
    public static void main(String[] args) {
        try (Scanner scanner = new Scanner(System.in)) {
            List<String> cadenas = new ArrayList<>();

            System.out.println("Introduce las cadenas de caracteres (una por línea). Para terminar, introduce una línea vacía:");

            while (true) {
                String cadena = scanner.nextLine();
                if (cadena.isEmpty()) {
                    break;
                }
                cadenas.add(cadena);
            }

            Collections.sort(cadenas, new Comparator<String>() {
                @Override
                public int compare(String s1, String s2) {
                    if (s1.length() != s2.length()) {
                        return Integer.compare(s1.length(), s2.length());
                    } else {
                        return s1.compareTo(s2);
                    }
                }
            });

            System.out.println("Cadenas ordenadas:");
            for (String cadena : cadenas) {
                System.out.println(cadena);
            }
        }
    }
}