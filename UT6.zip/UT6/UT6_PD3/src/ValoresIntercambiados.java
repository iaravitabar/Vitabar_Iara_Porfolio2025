import java.util.HashMap;
import java.util.Map;

public class ValoresIntercambiados {
    public static Map<String, String> invertirMapa(Map<String, String> mapaOriginal) throws IllegalArgumentException {
        Map<String, String> mapaInvertido = new HashMap<>();
        
        for (Map.Entry<String, String> entrada : mapaOriginal.entrySet()) {
            String clave = entrada.getKey();
            String valor = entrada.getValue();
            
            if (mapaInvertido.containsKey(valor)) {
                throw new IllegalArgumentException("Valor duplicado encontrado: " + valor);
            }
            
            mapaInvertido.put(valor, clave);
        }
        
        return mapaInvertido;
    }

    public static void main(String[] args) {
        Map<String, String> mapaOriginal = new HashMap<>();
        mapaOriginal.put("uno", "1");
        mapaOriginal.put("dos", "2");
        mapaOriginal.put("tres", "3");

        try {
            Map<String, String> mapaInvertido = invertirMapa(mapaOriginal);
            System.out.println(mapaInvertido);
        } catch (IllegalArgumentException e) {
            System.err.println(e.getMessage());
        }
    }
}