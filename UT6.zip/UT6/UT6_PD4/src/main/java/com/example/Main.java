package com.example;


import java.util.Map;

public class Main {
    public static void main(String[] args) {
        // Ruta del archivo libro.txt
        String rutaArchivo = "UT6_PD4\\libro.txt";

        FrecuenciaPalabras frecuenciaPalabras = new FrecuenciaPalabras();
        Map<String, Integer> frecuencias = frecuenciaPalabras.calcularFrecuencias(rutaArchivo);

        frecuenciaPalabras.mostrarTopFrecuencias(frecuencias, 10);
    }
}