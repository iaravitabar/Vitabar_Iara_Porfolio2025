package main.java.com.example;


import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.PriorityQueue;
import java.util.Comparator;

public class FrecuenciaPalabras {
    public Map<String, Integer> calcularFrecuencias(String rutaArchivo) {
        Map<String, Integer> frecuenciaPalabras = new HashMap<>();

        try (BufferedReader br = new BufferedReader(new FileReader(rutaArchivo))) {
            String linea;
            while ((linea = br.readLine()) != null) {
                String[] palabras = linea.split("\\W+");
                for (String palabra : palabras) {
                    if (!palabra.isEmpty()) {
                        palabra = palabra.toLowerCase();
                        frecuenciaPalabras.put(palabra, frecuenciaPalabras.getOrDefault(palabra, 0) + 1);
                    }
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        return frecuenciaPalabras;
    }

    public void mostrarTopFrecuencias(Map<String, Integer> frecuenciaPalabras, int topN) {
        PriorityQueue<Map.Entry<String, Integer>> cola = new PriorityQueue<>(
                Comparator.comparingInt(Map.Entry::getValue));

        for (Map.Entry<String, Integer> entrada : frecuenciaPalabras.entrySet()) {
            cola.add(entrada);
            if (cola.size() > topN) {
                cola.poll();
            }
        }

        System.out.println("Las " + topN + " palabras más frecuentes son:");
        while (!cola.isEmpty()) {
            Map.Entry<String, Integer> entrada = cola.poll();
            System.out.println(entrada.getKey() + ": " + entrada.getValue());
        }
    }
}