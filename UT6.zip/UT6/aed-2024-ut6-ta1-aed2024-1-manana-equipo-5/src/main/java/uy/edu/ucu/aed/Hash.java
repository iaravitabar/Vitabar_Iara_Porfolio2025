package uy.edu.ucu.aed;

import java.lang.reflect.Array;

public class Hash implements IHash{

    private int tamano;
    private Integer[] tabla;

    public Hash(int tamaño) {
        tamano = tamaño;
        tabla = new Integer[tamano];
    }

    @Override
    public int buscar(int unaClave) {
        int i = 0;
        while(i != tamano){
            int j = (funcionHashing(unaClave) + i) % tamano;
            if(tabla[j] == unaClave){
                return i; 
            }
            if(tabla[j] == null){
                return -1;
            }
            i += 1;
        }
        return -1;
    }

    @Override
    public int insertar(int unaClave) {
        int i = 0;
        while (i < tamano) {
            int j = (funcionHashing(unaClave) + i) % tamano;
            if (tabla[j] == null) {
                tabla[j] = unaClave;
                return i;
            } else {
                i++;
            }
        }
        return -1;
    }

    @Override
    public int funcionHashing(int unaClave) {
        return unaClave;
    }
    
}
