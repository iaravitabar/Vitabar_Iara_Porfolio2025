package com.example;

public class Main {
    public static void main(String[] args) {
        System.out.println("Hello world!");
    }
}
/*
 * UNIDAD TEMÁTICA 3: Listas, Pilas y Colas
    PRACTICOS DOMICILIARIOS INDIVIDUALES
    Ejercicios #1-5 Lista encadenada
Los nodos de una lista simplemente encadenada tienen dos atributos:
• DATOS, de tipo “dato”.
• SIGUIENTE, de tipo “nodo de lista”, que hace referencia al nodo siguiente en la
lista.

Ejercicio #1
Sean nodo1, nodo2 y nodo3 tres nodos consecutivos de una lista (nodo2 es el siguiente a
nodo1 y nodo3 es el siguiente a nodo2).
Analice el siguiente fragmento de código (utilice dibujos o diagramas para clarificar qué es lo
que sucede):
Nuevo nodo otroNodo
otroNodo.siguiente  nodo1
nodo2.siguiente  nodo3
a) Inserta “otroNodo” en la lista, quedando como anterior a nodo1.
b) Inserta “otroNodo” en la lista, quedando entre nodo1 y nodo2.
c) Elimina nodo2 de la lista.
d) No tiene ningún efecto sobre la lista.

    El siguiente codigo, crea un nuevo nodo llamado otroNodo y lo inserta en la lista
    al principio porque el siguiente es nodo1. respuesta es A
 */

/*
  * Ejercicio #2
    Sean nodo1, nodo2 y nodo3 tres nodos consecutivos de una lista (nodo2 es el siguiente a
    nodo1 y nodo3 es el siguiente a nodo2).
    Analice el siguiente fragmento de código (utilice dibujos o diagramas para clarificar qué es lo
    que sucede):
Nuevo nodo otroNodo
otroNodo  nodo1.siguiente
nodo1.siguiente  nodo3

a) Inserta “otroNodo” en la lista, quedando como anterior a nodo1.
b) Inserta “otroNodo” en la lista, quedando entre nodo1 y nodo2.
c) Elimina nodo2 de la lista.
d) No tiene ningún efecto sobre la lista.

    En este caso, se crea un nuevo nodo que apunta al siguiente al nodo1 y
    nodo1 apunta a nodo3, enconces inserta "otroNodo", en la lista quedando entre nodo1 y 2.
    
        1) nodo1 -> nodo2-> nodo3>null
        2)nodo1->otroNodo ->nodo2 -> nodo3 -null
        3)nodo1 -> nodo 3 -> otroNodo -> nodo2-null

    EJERCICIO #3
    Nuevo nodo otroNodo
otroNodo.siguiente  nodo1.siguiente
nodo1.siguiente  otroNodo
a) Inserta “otroNodo” en la lista, quedando como anterior a nodo1.
b) Inserta “otroNodo” en la lista, quedando entre nodo1 y nodo2.
c) Elimina nodo2 de la lista.
d) Dará error en tiempo de ejecución si nodo1 es el primero o nodo3 es el último.

    1) nodo1-> nodo2 -> nodo3 -> null
    2)nodo1 ->otroNodo -> nodo2 -> nodo3 -> null
  */

/*
 * Ejercicio #4
Analice el siguiente fragmento de código (utilice dibujos o diagramas para clarificar qué es lo
que sucede) y responda las preguntas proyectadas en pantalla:

Nuevo nodo otroNodo
Nuevo nodo nodoActual
nodoActual  primero
mientras nodoActual <> nulo hacer
nodoActual  nodoActual.siguiente
fin mientras
nodoActual.siguiente  otroNodo

a) Inserta correctamente “otroNodo” en la lista, quedando como último nodo.
b) Inserta correctamente “otroNodo” en la lista, quedando como primer nodo.
c) El algoritmo está mal hecho, ya que dará error en tiempo de ejecución si la lista está
vacía.
d) El algoritmo está mal hecho, ya que dará siempre error en tiempo de ejecución.

    tomando como primero a la variable que almacena al 1er nodo,
    Inserta otroNodo al final de la lista, luego de iterar hasta que nodoActual sea null
        inserta nodoActual al pricipio, va iterando y moviendo de lugar hasta que sea nulo,
        osea, al final de la lista y ahi establece que el siguiente nodo desp de nodoActual sea 
        otroNodo(lo inserta al final).
 */

/*
  * Ejercicio #5
Analice el siguiente fragmento de código (utilice dibujos o diagramas para clarificar qué es lo
que sucede) y responda las preguntas proyectadas en pantalla:

Nuevo nodo otroNodo
Nuevo nodo nodoActual
nodoActual  primero
mientras nodoActual.siguiente <> nulo hacer
nodoActual  nodoActual.siguiente
fin mientras
nodoActual.siguiente  otroNodo

a) Inserta correctamente “otroNodo” en la lista, quedando como último nodo.
b) Inserta correctamente “otroNodo” en la lista, quedando como primer nodo.
c) El algoritmo está mal hecho, ya que dará error en tiempo de ejecución si la lista está
vacía.
d) El algoritmo está mal hecho, ya que dará siempre error en tiempo de ejecución.

    c) el algoritmo esta mal hecho porque si la lista esta vaciaprimero no tiene nodo siguiente.
  */

/*
 * Ejercicio #6
Escenario:
Se desea llevar un registro de asistencia de un cierto curso universitario, el cual contará con
una cantidad no determinada inicialmente de alumnos. Para ello, se ha decidido utilizar una
lista para representar los alumnos en este curso.
Cada elemento de la lista entonces tendrá un identificador del alumno y un campo que se ha
de incrementar cada vez que el alumno concurra a una clase. También se desea registrar el
total de clases impartidas en el curso, y con este dato luego para cada alumno obtener el
porcentaje de asistencia a las clases.
Las listas pueden implementarse físicamente de dos formas básicas: utilizando un array, o
armando una lista encadenada. Se desea la opinión experta de tu Equipo para determinar qué
utilizar para resolver eficientemente el problema planteado.
a) ¿Cuál es el costo de memoria en cada caso?
    Array:
b) ¿Cuáles son las consideraciones que tu Equipo haría referentes a la cantidad de
alumnos del curso que soporta cada tipo de estructura? (puedes considerar que, como
en la UCU, las inscripciones al curso suelen estar habilitadas desde varias semanas
antes de empezar el curso hasta dos semanas después de haber comenzado)
 */

