import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;

public class LineasAleatorias {

    public static void main(String[] args) {
        if (args.length < 2) {
            System.err.println("Uso: java LineasAleatorias <ruta-archivo> <numero-lineas>");
            System.exit(1);
        }

        String rutaArchivo = args[0];
        int numLineasImprimir = Integer.parseInt(args[1]);

        try {
            File archivo = new File(rutaArchivo);
            long tamanioArchivo = archivo.length();
            int longitudPromedioLinea = 50; // Tamaño promedio estimado de una línea en bytes

            // Estimar el número de líneas en el archivo
            int estimacionNumLineas = (int) (tamanioArchivo / longitudPromedioLinea);

            // Inicializar la lista con la capacidad estimada
            List<String> lineas = new ArrayList<>(estimacionNumLineas);

            // Leer el archivo y llenar la lista
            try (BufferedReader br = new BufferedReader(new FileReader(archivo))) {
                String linea;
                while ((linea = br.readLine()) != null) {
                    lineas.add(linea);
                }
            }

            // Barajar las líneas
            Collections.shuffle(lineas, new Random());

            // Imprimir las líneas solicitadas
            System.out.println("Líneas aleatorias:");
            for (int i = 0; i < Math.min(numLineasImprimir, lineas.size()); i++) {
                System.out.println(lineas.get(i));
            }

        } catch (IOException e) {
            e.printStackTrace();
        } catch (NumberFormatException e) {
            System.err.println("El segundo parámetro debe ser un número entero.");
        }
    }
}