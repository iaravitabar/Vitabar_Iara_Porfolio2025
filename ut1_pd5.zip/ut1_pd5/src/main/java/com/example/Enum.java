package com.example;


/*
 * UNIDAD TEMÁTICA 1: Introducción a JAVA
    PRACTICOS DOMICILIARIOS INDIVIDUALES #5
    EJERCICIO #1
    Revisar el tutorial de ORACLE, en la parte de tipos enumerados
    (http://docs.oracle.com/javase/tutorial/java/javaOO/enum.html)
    La declaración “enum” define una clase (llamada tipo enumerado). El cuerpo de esta clase
    puede incluir métodos y otros campos. En particular, el compilador automáticamente agrega
    algunos métodos especiales cuando crea un enum. Por ejemplo, tiene un método de valores
    estáticos que retorna un array que contiene todos los valores del enum en el orden en que
    fueron declarados.
    1) Escribe un ejemplo de uso de tal método, y asegúrate de comprender cómo funciona!!
    2) Teniendo presente el programa que tu Equipo escribió para contar vocales y
    consonantes en una cierta frase, ¿cómo podrías escribirlo nuevamente utilizando tipos
    enumerados?
 */

enum Talleiara {
    EXTRASMALL,
    SMALL,
    MEDIUM,
    LARGE
    }
public class Enum {
    public static void main(String[] args) {
        Talleiara pantalon = Talleiara.SMALL;
        switch(pantalon){
            case EXTRASMALL:
                System.out.println("talle del pantalon de iara es xs");
                break;
            case SMALL:
                System.out.println("talle de pantalon de iara es s");
                break;
            case MEDIUM:
                System.out.println("el talle de pantalon de iara es M");
                break;
            case LARGE:
                System.out.println("talle de pantalon de iara es L");
                break;
        }
    }
}
        
