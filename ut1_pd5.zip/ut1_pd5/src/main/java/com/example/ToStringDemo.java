package com.example;


/*
 * EJERCICIO #5 Conversión de números en strings
    http://docs.oracle.com/javase/tutorial/java/data/converting.html
    Dado el siguiente código:
    public class ToStringDemo {
    public static void main(String[] args) {
    double d = 888.51;
    String s = Double.toString(d);
    int dot = s.indexOf('.');
    System.out.println(dot + " digits " +
    "before decimal point.");
    System.out.println( (s.length() - dot - 1) +
    " digits after decimal point.");
    }
    }
    1) Indicar cuál es la salida obtenida al ejecutarlo.
        convierte el double d a string y cuenta cuantos digitos existen antes y despues del punto decimal.
        en este caso la salida sera 3 digitos antes y 2 digitos despues.
    2) Indicar por qué se imprime cada uno de los datos y la razón de su forma
         se imprime el primer dato porque primero convierte el double a string, de ahi se obtiene el valor del indice
         del punto decimal, como el indice empieza en 0, el indice del punto indica cuantos digitos existen anes y lo imprime
         se imprime el segundo dato porque luego de haberlo convertido en string, obtiene el largo de la secuencia de caracteres
         y a la misma se le resta el valor del indice del puntoy se le resta 1 unidad para no incluir el valor del punto decimal y corregir el error.
 */