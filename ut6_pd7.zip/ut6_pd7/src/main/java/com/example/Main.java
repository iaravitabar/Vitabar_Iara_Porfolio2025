package com.example;

public class Main {
    public static void main(String[] args) {
        
        Alumno alumno1 = new Alumno(1, "Juan Pérez", "juan@example.com");
        Alumno alumno2 = new Alumno(1, "Juan Pérez", "juan@example.com");

        
        if (alumno1.equals(alumno2)) {
            System.out.println("Los alumnos son iguales según el método equals.");
        } else {
            System.out.println("Los alumnos no son iguales según el método equals.");
        }

        // hash
        int hashCodeAlumno1 = alumno1.hashCode();
        int hashCodeAlumno2 = alumno2.hashCode();

        System.out.println("Código hash de alumno1: " + hashCodeAlumno1);
        System.out.println("Código hash de alumno2: " + hashCodeAlumno2);
    }
}