package com.example;

import java.util.Objects;

public class Alumno {
    private int ID;
    private String fullName;
    private String email;

    

    public Alumno(int i, String string, String string2) {
        //TODO Auto-generated constructor stub
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        Alumno alumno = (Alumno) obj;
        return ID == alumno.ID &&
                Objects.equals(fullName, alumno.fullName) &&
                Objects.equals(email, alumno.email);
    }

    @Override
    public int hashCode() {
        return Objects.hash(ID, fullName, email);
    }
}