package com.example;

public final class ContadorPalabras {
    public static int contarPalabras(String frase) {
        boolean countingWords = false;
        int wordCount = 0;

        for (int i = 0; i < frase.length(); i++) {
            char c = frase.charAt(i);

            if (Character.isLetter(c) || Character.isDigit(c)) {
                if (!countingWords) {
                    countingWords = true;
                    wordCount++;
                }
            } else {
                countingWords = false;
            }
        }
        
        return wordCount;
    }
    public static String countV_C(String frase){
        String vowels = "aeiouAEIOUáéíóúÁÉÍÓÚ";
        int countV = 0;
        int countC = 0;
        for(int i = 0 ; i< frase.length(); i++){
            char c = frase.charAt(i);
            if (Character.isLetter(c)) {
                if (vowels.contains(String.valueOf(c))) {
                    countV ++;
                } else {
                    countC ++;
                }
            }
        }
        return ("la cantidad de vocales son: " + countV + " y las consonantes son: " +countC);
    }
}
/*
Agregamos un segundo metodo a la clase ContadorPalabras en el cual se recibe la frase nuevamente, como controlamos cuantas vocales y consonantes
tiene hicimos un string de vocales con todas las posibilidades. Luego, recorremos la frase preguntando si lo que recibimos es una letra, en caso 
de que asi sea, le preguntamos si esa letra se encuentra dentro del string de vocales, si es asi lo suma al contador de vocales. 
Y en caso de que no sea asi esta se considera una consonante por descarte por lo que sumamos en el else al contador de consonantes.
*/