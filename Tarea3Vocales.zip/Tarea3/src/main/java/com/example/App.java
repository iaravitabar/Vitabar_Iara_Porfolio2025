package com.example;

public final class App {
    private App() {
    }

    public static void main(String[] args) {
        String[] pruebas = new String[]
        {
            " ",
            "H",
            "Hola",
            " Hola",
            "Hola ",
            "Hola mundo",
            "Hola mundo!",
            "Hola  mundo",
            "Una frase más larga",
            "1",
            "123",
            "1,23",
        };

        for (int i = 0; i < pruebas.length; i++)
        {
            int palabras = ContadorPalabras.contarPalabras(pruebas[i]);
            System.out.println("La frase " + (i + 1) + " tiene " + palabras + " palabras");
            ContadorPalabras.countV_C(pruebas[i]);
            System.out.println(ContadorPalabras.countV_C(pruebas[i]));
        }


    }
}
