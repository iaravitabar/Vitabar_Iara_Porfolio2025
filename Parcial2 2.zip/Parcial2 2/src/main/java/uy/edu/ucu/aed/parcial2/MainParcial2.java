package uy.edu.ucu.aed.parcial2;

import java.util.Collection;
import java.util.List;

import uy.edu.ucu.aed.*;

/**
 * Algoritmo y Estrucutras de Datos
 * Parcial 2 - Parte 3
 *
 */
public class MainParcial2 {
    public static void main(String[] args) {
        // Cargar grafo a partir de archivos de entrada
        TGrafoDeLaRed grafo = UtilGrafos.cargarGrafo("./src/main/java/uy/edu/ucu/aed/parcial2/vertices.txt",
                "./src/main/java/uy/edu/ucu/aed/parcial2/aristas.txt", false, TGrafoDeLaRed.class,
                TVerticeDeLaRed.class);

        // Calculo de todos los caminos entre dos vertices
        TCaminos<TEstacionDeLaRed> caminos = grafo.caminosDesdeHasta("Vertice_3", "Vertice_4");

        // Escribir archivo de salida con el resultado de la llamada anterior, con los
        // caminos ordenados de menor a mayor costo, uno por línea.

        Collection<TCamino<TEstacionDeLaRed>> caminosCollection = caminos.getCaminos();

        List<TCamino<TEstacionDeLaRed>> caminosOrdenados = new java.util.ArrayList<>(caminosCollection);
        caminosOrdenados.sort(null); // Uses natural ordering, ensure TCamino implements Comparable



        String [] lineasSalidas = 
        {
            "3 A 4" + caminos.imprimirCaminos(),
        };

        ManejadorArchivosGenerico.escribirArchivo("src/main/java/salida.txt", lineasSalidas);

    }
}
