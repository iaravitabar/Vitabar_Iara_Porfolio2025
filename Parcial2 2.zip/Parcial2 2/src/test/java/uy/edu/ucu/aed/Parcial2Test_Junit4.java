package uy.edu.ucu.aed;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Collection;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.jupiter.api.BeforeEach;

import uy.edu.ucu.aed.parcial2.TEstacionDeLaRed;
import uy.edu.ucu.aed.parcial2.TGrafoDeLaRed;
import uy.edu.ucu.aed.parcial2.TVerticeDeLaRed;

/**
 * Unit test for implemented methods.
 */
public class Parcial2Test_Junit4 
{
    String instanceVariable;
    TGrafoDeLaRed grafo;

    @BeforeEach
    public void setUp() {
        Collection<TVerticeDeLaRed> estaciones = new LinkedList<>();
        estaciones.add(new TVerticeDeLaRed("A", 2));
        estaciones.add(new TVerticeDeLaRed("B",1));
        estaciones.add(new TVerticeDeLaRed("C", 2));

        Collection<IArista> aristas = new LinkedList<>();
        aristas.add(new TArista("A", "B", 0));
        aristas.add(new TArista("B", "C", 0));
        aristas.add(new TArista("A", "C", 0));

        TGrafoDeLaRed grafo = new TGrafoDeLaRed(estaciones, aristas);
        
    }

    @After
    public void tearDown() {
        grafo = null;
    }

    /**
     * Sample test in JUnit 4
     */

    @Test
    public void testCaminosDesdeHasta_MultiplesCaminos() {
        List<LinkedList<TVerticeDeLaRed>> caminos = (List<LinkedList<TVerticeDeLaRed>>) grafo.caminosDesdeHasta("A", "C");
        assertEquals(2, caminos.size());

        // Verifica que los caminos sean A->B->C y A->C
        Set<String> caminosStr = new HashSet<>();
        for (LinkedList<TVerticeDeLaRed> camino : caminos) {
            StringBuilder sb = new StringBuilder();
            for (TVerticeDeLaRed v : camino) {
                sb.append(v.getEtiqueta());
            }
            caminosStr.add(sb.toString());
        }
        assertTrue(caminosStr.contains("ABC"));
        assertTrue(caminosStr.contains("AC"));
    }
    @Test
    public void noCamino()
    {
        TCaminos<TEstacionDeLaRed> caminos = grafo.caminosDesdeHasta("C", "A");
        assertNotNull(caminos);
        assertTrue(caminos.getCaminos().isEmpty());
    }
    @Test 
    public void mismoCamino ()
    {
        TCaminos<TEstacionDeLaRed> caminos = grafo.caminosDesdeHasta("A", "A");
        assertNotNull(caminos);
        assertTrue(caminos.getCaminos().isEmpty());
    }
}
