package com.example;

import java.util.ArrayList;
import java.util.List;

/*
 * UNIDAD TEMÁTICA 1: Introducción a JAVA
        TRABAJO DE APLICACIÓN 4
        NOTA: UTILIZAR LAS LECTURAS RECOMENDADAS COMO REFERENCIA
        Ejercicio #1 – Manipular strings y Mostrar contenido de un array
        Parte 1
        En la clase ContadorPalabras, se desea agregar una función que reciba por parámetros 2 vectores de
        palabras (arrays de tipo String) y devuelva otro vector (array de Strings) conteniendo solamente las
        palabras que se encuentren en ambos vectores de entrada.
        Por ejemplo:
        Ar1={“Hola”, “mundo”, “de”, “los”, “algoritmos”}
        Ar2={“Hola”, “mundo”, “de”, “la”, “informática”}
        arResultado = {“Hola”, “mundo”, “de”}
        firma del método de la clase contadorPalabras:
        String[] palabrasComunes(String[] palabras1, String[] palabras2)
        
        Trabajo a realizar:
        a) Describir mediante lenguaje natural la nueva funcionalidad.
            crear un nuevo metodo que reciba dos vectores de palabras y devuelva un vector con las palabras que se
            encuentran en ambos vectores.
        b) Desarrollar e implementar el método solicitado.
        NOTAS IMPORTANTES:
        1. Utilizar construcciones while o for estándar para las recorridas de los vectores
        2. Optimizar la generación de strings usando las clases JAVA más apropiadas
 */
public class ContadorPalabras {

    public String[] palabrasComunes(String[] palabras1, String[] palabras2) {
        List<String> palabrasComunes = new ArrayList<>();
        for (String palabra : palabras1) {
            if (contienePalabra(palabra, palabras2)) {
                palabrasComunes.add(palabra);
            }
        }
        return palabrasComunes.toArray(new String[0]);
    }

    private boolean contienePalabra(String palabra, String[] palabras) {
        for (String p : palabras) {
            if (palabra.equals(p)) {
                return true;
            }
        }
        return false;
    }
    public static void main(String[] args) {
        String[] ar1 = {"Hola", "mundo", "a"};
        String[] ar2 = {"Hola", "mundo", "b"};

        ContadorPalabras contador = new ContadorPalabras();
        String[] resultado = contador.palabrasComunes(ar1, ar2);
        System.out.println("Palabras comunes:");
        for (String palabra : resultado) {
            System.out.print(palabra + " ");
        }
    }
}